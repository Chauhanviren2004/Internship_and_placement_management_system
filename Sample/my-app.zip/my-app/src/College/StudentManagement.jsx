import React, { useState } from "react";
import CollegeSidebar from "./CollegeSidebar"; // Ensure case sensitivity matches your file

const StudentManagement = () => {
  // Sample student data
  const [students, setStudents] = useState([
    { id: 1, name: "Khushi Trivedi", email: "khushi@example.com", selected: true },
    { id: 2, name: "Raj Patel", email: "raj@example.com", selected: false },
    { id: 3, name: "Sneha Sharma", email: "sneha@example.com", selected: true },
    { id: 4, name: "Amit Desai", email: "amit@example.com", selected: false },
  ]);

  // Toggle selection
  const toggleSelection = (id) => {
    setStudents(
      students.map((student) =>
        student.id === id ? { ...student, selected: !student.selected } : student
      )
    );
  };

  return (
    <div className="college-container">
      {/* Sidebar - Positioned on the left via CSS flex */}
      <CollegeSidebar />

      {/* Main Content Area */}
      <main className="college-main-content student-management">
        <header className="content-header">
          <h2>Student Shortlist</h2>
          <p>Check which students are selected for internships.</p>
        </header>

        <div className="student-list">
          {students.map((student) => (
            <div
              key={student.id}
              className={`student-card ${student.selected ? "selected" : ""}`}
            >
              <div className="student-info">
                <h3>{student.name}</h3>
                <p>{student.email}</p>
              </div>
              <button
                className={`select-btn ${student.selected ? "selected-btn" : ""}`}
                onClick={() => toggleSelection(student.id)}
              >
                {student.selected ? "Selected" : "Select"}
              </button>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default StudentManagement;