import React from "react";
import CollegeSidebar from "./CollegeSidebar";

const ReportAnalysis = () => {
  const reports = [
    { id: 1, title: "Internship Applications Overview", status: "Completed", progress: 90 },
    { id: 2, title: "Student Selection Analysis", status: "In Progress", progress: 65 },
    { id: 3, title: "Placement Stats", status: "Pending", progress: 30 },
    { id: 4, title: "Department-wise Reports", status: "Completed", progress: 100 },
  ];

  return (
    <div className="college-container">
      {/* Sidebar - should have a fixed width in CSS */}
      <CollegeSidebar />

      {/* Main Content - should have flex: 1 to fill space */}
      <main className="college-main-content">
        <header className="content-header">
          <h2>Report Analysis</h2>
          <p>Overview of student applications, selections, and departmental stats.</p>
        </header>

        <div className="report-cards">
          {reports.map((report) => (
            <div key={report.id} className="report-card">
              <div className="report-info">
                <h3>{report.title}</h3>
                <p>
                  Status:{" "}
                  <span className={`status-badge ${report.status.replace(/\s+/g, '-').toLowerCase()}`}>
                    {report.status}
                  </span>
                </p>
              </div>
              <div className="progress-bar-container">
                <div
                  className="progress-bar"
                  style={{ width: `${report.progress}%` }}
                ></div>
                <span className="progress-text">{report.progress}%</span>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default ReportAnalysis;