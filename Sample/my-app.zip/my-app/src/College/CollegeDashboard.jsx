import React, { useState } from "react";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import CollegeSidebar from "./CollegeSidebar"; // Ensure case sensitivity matches

const CollegeDashboard = () => {
  const navigate = useNavigate();

  // ✅ Logout Function
  const handleLogout = () => {
    localStorage.removeItem("user"); 
    navigate("/"); 
  };

  return (
    /* This is the Flex Container */
    <div className="college-dashboard-container">
      
      {/* 1. Sidebar is now a DIRECT child of the flex container */}
      <CollegeSidebar />

      {/* 2. Main Content is the second DIRECT child */}
      <div className="main-content">
        
        <header className="dashboard-header">
          <h4>College Dashboard</h4>
          <button className="btn-logout" onClick={handleLogout}>
            Logout
          </button>
        </header>

        <main className="dashboard-body">
          {/* This renders the child routes like Company Approval or Student Management */}
          <Outlet />
        </main>

      </div>
    </div>
  );
};

export default CollegeDashboard;