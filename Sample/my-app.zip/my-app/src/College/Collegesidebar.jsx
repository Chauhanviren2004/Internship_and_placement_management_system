import React from "react";
import { Link } from "react-router-dom";


const CollegeSidebar = () => {
  return (
    <div className="college-sidebar">

      <h3 className="sidebar-title">College Panel</h3>

      <ul className="sidebar-menu">

        <li>
          <Link to="/admin-dashboard">Dashboard</Link>
        </li>

        <li>
          <Link to="/company-approval">Company Approval</Link>
        </li>

        <li>
          <Link to="/student-management">Student Management</Link>
        </li>

        <li>
          <Link to="/report-analysis">Report Analysis</Link>
        </li>

      </ul>

    </div>
  );
};

export default CollegeSidebar;