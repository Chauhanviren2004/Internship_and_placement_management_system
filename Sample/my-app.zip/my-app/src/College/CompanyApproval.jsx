import React, { useState, useEffect } from "react";
import CollegeSidebar from "./CollegeSidebar";

const CompanyApproval = () => {
  const [internships, setInternships] = useState([]);

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem("internships")) || [];
    setInternships(data);
  }, []);

  const handleApprove = (index) => {
    const updated = [...internships];
    updated[index].status = "Approved";
    setInternships(updated);
    localStorage.setItem("internships", JSON.stringify(updated));
  };

  const handleReject = (index) => {
    const updated = [...internships];
    updated[index].status = "Rejected";
    setInternships(updated);
    localStorage.setItem("internships", JSON.stringify(updated));
  };

  const handleDelete = (index) => {
    const updated = [...internships];
    updated.splice(index, 1);
    setInternships(updated);
    localStorage.setItem("internships", JSON.stringify(updated));
  };

  return (
    /* Wrap everything in the layout container */
    <div className="college-container">
      <CollegeSidebar />
      
      {/* Wrap main content so it stays to the right of the sidebar */}
      <main className="college-main-content">
        <div className="company-approval-container">
          <h2>Company Approval</h2>

          {internships.length === 0 ? (
            <div className="no-data-card">
               <p>No internships submitted yet.</p>
            </div>
          ) : (
            <table className="company-approval-table">
              <thead>
                <tr>
                  <th>Company Name</th>
                  <th>Role / Description</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {internships.map((intern, index) => (
                  <tr key={index}>
                    <td>{intern.companyName}</td>
                    <td>{intern.description}</td>
                    <td>
                      <span className={`status-badge ${(intern.status || "Pending").toLowerCase()}`}>
                        {intern.status || "Pending"}
                      </span>
                    </td>
                    <td>
                      {(intern.status || "Pending") === "Pending" ? (
                        <div className="action-buttons">
                          <button className="btn-approve" onClick={() => handleApprove(index)}>Approve</button>
                          <button className="btn-reject" onClick={() => handleReject(index)}>Reject</button>
                          <button className="btn-delete" onClick={() => handleDelete(index)}>Delete</button>
                        </div>
                      ) : (
                        <div className="action-buttons">
                          <span>—</span>
                          <button className="btn-delete" onClick={() => handleDelete(index)}>Delete</button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </main>
    </div>
  );
};

export default CompanyApproval;