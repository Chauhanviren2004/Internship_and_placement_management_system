// import React, { useState } from "react";
// import { Briefcase, Mail, Lock, User, ArrowLeft } from "lucide-react";
// import { Link } from "react-router-dom"; // Import Link for internal navigation
// import "./Auth.css";

// const Register = () => {
//   const [role, setRole] = useState("student");

//   return (
//     <div className="auth-page">
//       <div className="auth-left-panel">
//         <div className="auth-glow-overlay"></div>
//         <div className="auth-branding">
//           <div className="auth-logo">
//             <Briefcase size={40} className="teal-icon" />
//             <span className="logo-name">HireHub</span>
//           </div>
//           <h1 className="auth-hero-text">Join the Community</h1>
//           <p className="auth-hero-desc">Create an account to start applying for top-tier internships or to hire the best talent.</p>
//         </div>
//       </div>

//       <div className="auth-right-panel">
//         <div className="form-container">
//           {/* Use Link instead of window.location */}
//           <Link to="/" className="back-home-btn">
//             <ArrowLeft size={16} /> Back to home
//           </Link>

//           <h2 className="form-title">Create Account</h2>
//           <p className="form-subtitle">Join thousands of students and companies today</p>

//           <form className="auth-form" onSubmit={(e) => e.preventDefault()}>
//             <div className="input-group">
//               <label>Full Name</label>
//               <div className="input-wrapper">
//                 <User className="input-icon" size={18} />
//                 <input type="text" placeholder="John Doe" required />
//               </div>
//             </div>

//             <div className="input-group">
//               <label>I am a</label>
//               <div className="role-selector">
//                 <button 
//                   type="button" 
//                   className={role === "student" ? "role-btn active" : "role-btn"}
//                   onClick={() => setRole("student")}
//                 >🎓 Student</button>
//                 <button 
//                   type="button" 
//                   className={role === "company" ? "role-btn active" : "role-btn"}
//                   onClick={() => setRole("company")}
//                 >🏢 Company</button>

// <button 
//                   type="button" class="button-74"
//                   className={role === "Admin" ? "role-btn active" : "role-btn"}
//                   onClick={() => setRole("Admin")}
//                 >🎓 Admin</button>





// {/* <button class="button-74" role="button">Button 74</button> */}







//               </div>
//             </div>

//             <div className="input-group">
//               <label>Email Address</label>
//               <div className="input-wrapper">
//                 <Mail className="input-icon" size={18} />
//                 <input type="email" placeholder="you@example.com" required />
//               </div>
//             </div>

//             <div className="input-group">
//               <label>Password</label>
//               <div className="input-wrapper">
//                 <Lock className="input-icon" size={18} />
//                 <input type="password" placeholder="Min. 8 characters" required minLength={8} />
//               </div>
//             </div>

//             <button type="submit" className="submit-btn">Create Free Account</button>
//           </form>

//           <p className="toggle-mode-text">
//             Already have an account? <Link to="/Login">Sign in</Link>
//           </p>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Register;



// import React, { useState } from "react";
// import { Briefcase, Mail, Lock, User, ArrowLeft } from "lucide-react";
// import { Link, useNavigate } from "react-router-dom"; // import useNavigate
// import "./Auth.css";

// const Register = () => {
//   const [role, setRole] = useState("student");
//   const[data,setData]=React.useState({})
//   const navigate = useNavigate(); // initialize navigate

//   const handleSubmit = (e) => {
//     e.preventDefault();

//     // Example: Save user info in localStorage
//     const userData = {
//       role: role,
//       // you can add more fields like name, email, etc.
//     };
//     localStorage.setItem("user", JSON.stringify(userData));

//     // Redirect based on role
//     if (role === "student") {
//       navigate("/student-dashboard");
//     } else if (role === "company") {
//       navigate("/company-dashboard");
//     } else if (role === "Admin") {
//       navigate("/admin-dashboard"); // change this to your actual admin route
//     }
//   };

//   return (
//     <div className="auth-page">
//       <div className="auth-left-panel">
//         <div className="auth-glow-overlay"></div>
//         <div className="auth-branding">
//           <div className="auth-logo">
//             <Briefcase size={40} className="teal-icon" />
//             <span className="logo-name">HireHub</span>
//           </div>
//           <h1 className="auth-hero-text">Join the Community</h1>
//           <p className="auth-hero-desc">
//             Create an account to start applying for top-tier internships or to hire the best talent.
//           </p>
//         </div>
//       </div>

//       <div className="auth-right-panel">
//         <div className="form-container">
//           <Link to="/" className="back-home-btn">
//             <ArrowLeft size={16} /> Back to home
//           </Link>

//           <h2 className="form-title">Create Account</h2>
//           <p className="form-subtitle">Join thousands of students and companies today</p>

//           {/* Updated onSubmit */}
//           <form className="auth-form" onSubmit={handleSubmit}>
//             <div className="input-group">
//               <label>Full Name</label>
//               <div className="input-wrapper">
//                 <User className="input-icon" size={18} />
//                 <input type="text" placeholder="John Doe" required />
//               </div>
//             </div>

//             <div className="input-group">
//               <label>I am a</label>
//               <div className="role-selector">
//                 <button 
//                   type="button" 
//                   className={role === "student" ? "role-btn active" : "role-btn"}
//                   onClick={() => setRole("student")}
//                 >🎓 Student</button>
//                 <button 
//                   type="button" 
//                   className={role === "company" ? "role-btn active" : "role-btn"}
//                   onClick={() => setRole("company")}
//                 >🏢 Company</button>
//                 <button 
//                   type="button" 
//                   className={role === "Admin" ? "role-btn active" : "role-btn"}
//                   onClick={() => setRole("Admin")}
//                 >🛡️ Admin</button>
//               </div>
//             </div>

//             <div className="input-group">
//               <label>Email Address</label>
//               <div className="input-wrapper">
//                 <Mail className="input-icon" size={18} />
//                 <input type="email" placeholder="you@example.com" required />
//               </div>
//             </div>

//             <div className="input-group">
//               <label>Password</label>
//               <div className="input-wrapper">
//                 <Lock className="input-icon" size={18} />
//                 <input type="password" placeholder="Min. 8 characters" required minLength={8} />
//               </div>
//             </div>

//             <button type="submit" className="submit-btn" onClick={()=>{
//               axios.post('http://127.0.0.1:8000/student/register',)
//               .then((res)=>{
//                 console.log(res)
//               })
//               .catch((err)=>{
//                 console.log("Error",err)
//               })
//             }}>Create Free Account</button>
//           </form>

//           <p className="toggle-mode-text">
//             Already have an account? <Link to="/Login">Sign in</Link>
//           </p>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Register;



// import React, { useState } from "react";
// import { Briefcase, Mail, Lock, User, ArrowLeft } from "lucide-react";
// import { Link, useNavigate } from "react-router-dom";
// import axios from "axios";
// import "./Auth.css";

// const Register = () => {
//   const navigate = useNavigate();

//   const [formData, setFormData] = useState({
//     name: "",
//     email: "",
//     password: "",
//   });

//   // Handle input
//   const handleChange = (e) => {
//     setFormData({
//       ...formData,
//       [e.target.name]: e.target.value,
//     });
//   };

//   // Submit
//   const handleSubmit = (e) => {
//     // e.preventDefault();

//     axios
//       .post("http://127.0.0.1:8000/student/register", formData)
//       .then((res) => {
//         console.log("Success:", res.data);

//       navigate("/login");
//       })
//       .catch((err) => {
//         console.log("Error:", err.response?.data || err.message);
//       });
//   };

//   return (
//     <div className="auth-page">
//       <div className="auth-left-panel">
//         <div className="auth-glow-overlay"></div>
//         <div className="auth-branding">
//           <div className="auth-logo">
//             <Briefcase size={40} className="teal-icon" />
//             <span className="logo-name">HireHub</span>
//           </div>
//           <h1 className="auth-hero-text">Join the Community</h1>
//         </div>
//       </div>

//       <div className="auth-right-panel">
//         <div className="form-container">
//           <Link to="/" className="back-home-btn">
//             <ArrowLeft size={16} /> Back to home
//           </Link>

//           <h2 className="form-title">Create Account</h2>

            
//             {/* Name */}
//             <div className="input-group">
//               <label>Full Name</label>
//               <div className="input-wrapper">
//                 <User size={18} />
//                 <input
//                   type="text"
//                   name="name"
//                   placeholder="John Doe"
//                   required
//                   value={formData.name}
//                   onChange={handleChange}
//                 />
//               </div>
//             </div>

//             {/* Email */}
//             <div className="input-group">
//               <label>Email</label>
//               <div className="input-wrapper">
//                 <Mail size={18} />
//                 <input
//                   type="email"
//                   name="email"
//                   placeholder="you@example.com"
//                   required
//                   value={formData.email}
//                   onChange={handleChange}
//                 />
//               </div>
//             </div>

//             {/* Password */}
//             <div className="input-group">
//               <label>Password</label>
//               <div className="input-wrapper">
//                 <Lock size={18} />
//                 <input
//                   type="password"
//                   name="password"
//                   placeholder="Min. 8 characters"
//                   required
//                   minLength={8}
//                   value={formData.password}
//                   onChange={handleChange}
//                 />
//               </div>
//             </div>

//             {/* Submit */}
//             <button className="submit-btn" onClick={handleSubmit}>
//               Create Account
//             </button>

//           <p>
//             Already have an account? <Link to="/Login">Login</Link>
//           </p>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Register;







// import React, { useState } from "react";
// import { Briefcase, Mail, Lock, User, ArrowLeft } from "lucide-react";
// import { Link, useNavigate } from "react-router-dom";
// import "./Auth.css";

// const Register = () => {
//   const [role, setRole] = useState("student");
//   const navigate = useNavigate();

//   const handleSubmit = (e) => {
//     e.preventDefault();

//     // Redirect based on role
//     if (role === "student") navigate("/student-dashboard");
//     if (role === "company") navigate("/company-dashboard");
//     if (role === "admin") navigate("/admin-dashboard");
//   };

//   return (
//     <div className="auth-page">
//       {/* LEFT */}
//       <div className="auth-left-panel">
//         <div className="auth-branding">
//           <div className="auth-logo">
//             <Briefcase size={32} />
//             <span>HireHub</span>
//           </div>

//           <h1>Join the Community</h1>
//           <p>
//             Create an account to start applying for top-tier internships or to
//             hire the best talent.
//           </p>
//         </div>
//       </div>

//       {/* RIGHT */}
//       <div className="auth-right-panel">
//         <div className="form-container">
//           <Link to="/" className="back-home-btn">
//             <ArrowLeft size={16} /> Back to home
//           </Link>

//           <h2>Create Account</h2>
//           <p className="subtitle">
//             Join thousands of students and companies today
//           </p>

//           <form onSubmit={handleSubmit}>
//             {/* NAME */}
//             <div className="input-group">
//               <label>FULL NAME</label>
//               <div className="input-wrapper">
//                 <User size={18} />
//                 <input type="text" placeholder="John Doe" required />
//               </div>
//             </div>

//             {/* ROLE */}
//             <div className="input-group">
//               <label>I AM A</label>
//               <div className="role-selector">
//                 <button
//                   type="button"
//                   className={role === "student" ? "active" : ""}
//                   onClick={() => setRole("student")}
//                 >
//                   🎓 Student
//                 </button>

//                 <button
//                   type="button"
//                   className={role === "company" ? "active" : ""}
//                   onClick={() => setRole("company")}
//                 >
//                   🏢 Company
//                 </button>

//                 <button
//                   type="button"
//                   className={role === "admin" ? "active" : ""}
//                   onClick={() => setRole("admin")}
//                 >
//                   🛡 Admin
//                 </button>
//               </div>
//             </div>

//             {/* EMAIL */}
//             <div className="input-group">
//               <label>EMAIL ADDRESS</label>
//               <div className="input-wrapper">
//                 <Mail size={18} />
//                 <input type="email" placeholder="you@gmail.com" required />
//               </div>
//             </div>

//             {/* PASSWORD */}
//             <div className="input-group">
//               <label>PASSWORD</label>
//               <div className="input-wrapper">
//                 <Lock size={18} />
//                 <input type="password" required />
//               </div>
//             </div>

//             <button type="submit" className="submit-btn">
//               Create Free Account
//             </button>
//           </form>

//           <p className="bottom-text">
//             Already have an account? <Link to="/login">Sign in</Link>
//           </p>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Register;




// // http://127.0.0.1:8000/admin/register





import React, { useState } from "react";
import { Briefcase, Mail, Lock, User, ArrowLeft } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import "./Auth.css";

const Register = () => {
  const [role, setRole] = useState("student");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Decide endpoint based on role
    let url = "";
    if (role === "student") url = "http://127.0.0.1:8000/student/register";
    if (role === "company") url = "http://127.0.0.1:8000/company/register";
    if (role === "admin") url = "http://127.0.0.1:8000/admin/register";

    try {
      const response = await axios.post(url, {
        name,
        email,
        password,
      });

      if (response.status === 200 || response.status === 201) {
        alert("Registration Successful ✅");
        // Redirect based on role
        navigate("/login");

        // if (role === "student") navigate("/student-dashboard");
        // if (role === "company") navigate("/company-dashboard");
        // if (role === "admin") navigate("/admin-dashboard");
      }
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.detail || "Something went wrong!");
    }
  };

  return (
    <div className="auth-page">
      {/* LEFT */}
      <div className="auth-left-panel">
        <div className="auth-branding">
          <div className="auth-logo">
            <Briefcase size={32} />
            <span>HireHub</span>
          </div>
          <h1>Join the Community</h1>
          <p>
            Create an account to start applying for top-tier internships or to
            hire the best talent.
          </p>
        </div>
      </div>

      {/* RIGHT */}
      <div className="auth-right-panel">
        <div className="form-container">
          <Link to="/" className="back-home-btn">
            <ArrowLeft size={16} /> Back to home
          </Link>

          <h2>Create Account</h2>
          <p className="subtitle">Join thousands of students and companies today</p>

          <form onSubmit={handleSubmit}>
            {/* NAME */}
            <div className="input-group">
              <label>FULL NAME</label>
              <div className="input-wrapper">
                <User size={18} />
                <input
                  type="text"
                  placeholder="John Doe"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
            </div>

            {/* ROLE */}
            <div className="input-group">
              <label>I AM A</label>
              <div className="role-selector">
                <button
                  type="button"
                  className={role === "student" ? "active" : ""}
                  onClick={() => setRole("student")}
                >
                  🎓 Student
                </button>

                <button
                  type="button"
                  className={role === "company" ? "active" : ""}
                  onClick={() => setRole("company")}
                >
                  🏢 Company
                </button>

                <button
                  type="button"
                  className={role === "admin" ? "active" : ""}
                  onClick={() => setRole("admin")}
                >
                  🛡 Admin
                </button>
              </div>
            </div>

            {/* EMAIL */}
            <div className="input-group">
              <label>EMAIL ADDRESS</label>
              <div className="input-wrapper">
                <Mail size={18} />
                <input
                  type="email"
                  placeholder="you@gmail.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </div>

            {/* PASSWORD */}
            <div className="input-group">
              <label>PASSWORD</label>
              <div className="input-wrapper">
                <Lock size={18} />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            </div>

            <button type="submit" className="submit-btn">
              Create Free Account
            </button>
          </form>

          <p className="bottom-text">
            Already have an account? <Link to="/login">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Register;