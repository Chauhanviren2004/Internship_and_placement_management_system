import React, { useState } from "react";
import { Menu, X, Briefcase, MessageCircle } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  const user = JSON.parse(localStorage.getItem("user"));
  const role = user?.role;

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/login");
  };

  return (
    <nav className="navbar">
      <div className="nav-container">

        {/* LOGO */}
        <Link to="/" className="logo-group">
          <div className="logo-icon">
            <Briefcase size={20} color="#0dcaf0" />
          </div>
          <span className="logo-text">
            Hire<span className="teal-text">Hub</span>
          </span>
        </Link>

        {/* NAV LINKS */}
        <div className="nav-links">
          <Link to="/internship">Internships</Link>

          {role === "company" && (
            <Link to="/company-dashboard">Companies</Link>
          )}

          {role === "student" && (
            <Link to="/student-dashboard">Students</Link>
          )}

          {role === "Admin" && (
            <Link to="/college-dashboard">College</Link>
          )}

          <Link to="/feedback" className="feedback-link">
            <MessageCircle size={16} style={{ marginRight: "5px" }} />
            Feedback
          </Link>
        </div>

        {/* RIGHT BUTTON */}
        <div className="nav-actions">
          {!user ? (
            <Link to="/login" className="btn-primary">
              Sign In
            </Link>
          ) : (
            <button className="btn-logout" onClick={handleLogout}>
              Logout
            </button>
          )}
        </div>

        {/* MOBILE TOGGLE */}
        <button className="mobile-toggle" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* MOBILE MENU */}
      {isOpen && (
        <div className="mobile-menu">
          <Link to="/internship" onClick={() => setIsOpen(false)}>Internships</Link>

          {role === "company" && (
            <Link to="/company-dashboard" onClick={() => setIsOpen(false)}>Companies</Link>
          )}

          {role === "student" && (
            <Link to="/student-dashboard" onClick={() => setIsOpen(false)}>Students</Link>
          )}

          {role === "Admin" && (
            <Link to="/college-dashboard" onClick={() => setIsOpen(false)}>College</Link>
          )}

          <Link to="/feedback" onClick={() => setIsOpen(false)}>Feedback</Link>

          <hr />

          {!user ? (
            <Link to="/login">Sign In</Link>
          ) : (
            <button onClick={handleLogout}>Logout</button>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;