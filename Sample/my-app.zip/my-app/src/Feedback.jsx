import React, { useState } from "react";

const Feedback = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    type: "General Feedback",
    message: ""
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // You can send this data to backend or API
    alert(`Feedback Submitted!\nType: ${formData.type}\nMessage: ${formData.message}`);
    setFormData({ name: "", email: "", type: "General Feedback", message: "" });
  };

  return (
    <div className="container py-5">
      <h2 className="mb-4 fw-bold">Send Us Your Feedback</h2>

      <form onSubmit={handleSubmit} className="card p-4 shadow-sm">

        <div className="mb-3">
          <label className="form-label">Name</label>
          <input
            type="text"
            name="name"
            className="form-control"
            placeholder="Your Name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Email</label>
          <input
            type="email"
            name="email"
            className="form-control"
            placeholder="Your Email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>

        {/* ✅ Feedback Type Dropdown */}
        <div className="mb-3">
          <label className="form-label">Type of Feedback</label>
          <select
            name="type"
            className="form-select"
            value={formData.type}
            onChange={handleChange}
          >
            <option>General Feedback</option>
            <option>Internship Issue</option>
            <option>Website Bug</option>
            <option>Other</option>
          </select>
        </div>

        <div className="mb-3">
          <label className="form-label">Message</label>
          <textarea
            name="message"
            rows="4"
            className="form-control"
            placeholder="Write your feedback here..."
            value={formData.message}
            onChange={handleChange}
            required
          ></textarea>
        </div>

        <button type="submit" className="btn btn-info text-white">
          Submit Feedback
        </button>

      </form>
    </div>
  );
};

export default Feedback;