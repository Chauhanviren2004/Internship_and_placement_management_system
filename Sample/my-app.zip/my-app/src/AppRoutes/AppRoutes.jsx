import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';



// Landing Page Components
import Navbar from '../Navbar';
import HeroSection from '../HeroSection';
import StatsSection from '../StatsSection';
import CompaniesSection from '../CompaniesSection';
import InternshipsSection from '../InternshipSection';
import HowItWorksSection from '../HowItWorksSection';
import TestimonialsSection from '../TestimonialsSection';
import CTASection from '../CTASection';
import Footer from '../Footer';
import Feedback from '../Feedback';
import InternshipPage from '../InternshipPage';

// Auth Pages
import Login from '../Login';
import Register from '../Register';

// Student Dashboard Components
import StudentDashboard from '../Student/StudentDashboard';
import ApplicationStatus from '../Student/Applicationstatus';
import InternshipList from '../Student/InternshipList';
import InternshipProgress from '../Student/InternshipProgress';
import Messages from '../Student/Messages';
import ProfilePage from '../Student/ProfilePage';
import ResumeUpload from '../Student/ResumeUpload';
import ApplyInternship from '../Student/ApplyInternship';

// company
import Chat from '../Company/Chat';
import CompanyDashboard from '../Company/CompanyDashboard';
import FeedbackStatus from '../Company/FeedbackStatus';
import PostInternship from '../Company/PostInternship';
import StudentResumeList from '../Company/StudentResumeList';
import ShortlistStudents from '../Company/ShortlistStudents';

// college
import CollegeDashboard from '../College/CollegeDashboard';
import CompanyApproval from '../College/CompanyApproval';
import StudentManagement from '../College/StudentManagement';
import ReportAnalysis from '../College/ReportAnalysis';

// Landing Page Wrapper
const Home = () => (
  <>
     {/* Navigation Bar */}
      <Navbar />

      {/* Hero / Intro Section */}
      <HeroSection />

      {/* Statistics Section */}
    

      {/* Companies Section */}
      <CompaniesSection />

      {/* Featured Internships Section */}
      <InternshipsSection />

      {/* How It Works Section */}
      <HowItWorksSection />

      {/* Testimonials Section */}
      <TestimonialsSection />

      {/* Call To Action Section */}
      <CTASection />
  <StatsSection />
      {/* Footer */}
      <Footer />
  </>
);

const AppRoute = () => {
  return (
    <div>
      
  
    <Router>
      <Routes>
        {/* Landing Page */}
        <Route path="/" element={<Home />} />

        {/* Auth Routes */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/Feedback" element={<Feedback />} />
        <Route path='/internship' element={<InternshipPage/>}/>

        {/* Student Dashboard Layout */}
        <Route path="/student-dashboard" element={<StudentDashboard />}/>
          <Route path="/application-status" element={<ApplicationStatus />} />
          <Route path="/internship-list" element={<InternshipList />} />
          <Route path="/internship-progress" element={<InternshipProgress />} />
          <Route path="/messages" element={<Messages />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/resume-upload" element={<ResumeUpload />} />
          <Route path="/apply-internship" element={<ApplyInternship />} />

          {/* Company dashboard */}
          <Route path="/company-dashboard" element={<CompanyDashboard />} />
<Route path="/company/post-internship" element={<PostInternship />} />
<Route path="/company/student-resumes" element={<StudentResumeList />} />
<Route path="/company/shortlist" element={<ShortlistStudents />} />
<Route path="/company/feedback" element={<FeedbackStatus />} />
<Route path="/company/chat" element={<Chat />} />

{/* College dashboard */}
        
<Route path="/admin-dashboard" element={<CollegeDashboard />}/>
  <Route path="/company-approval" element={<CompanyApproval />} />
<Route path="/student-management" element={<StudentManagement/>}/>
 <Route  path="/report-analysis" element={<ReportAnalysis/>}/>   
      </Routes>
    </Router>
      </div>
  );
};

export default AppRoute;
  



// import React from "react";
// import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// // Landing Page Components
// import Navbar from "../Navbar";
// import HeroSection from "../HeroSection";
// import StatsSection from "../StatsSection";
// import CompaniesSection from "../CompaniesSection";
// import InternshipsSection from "../InternshipSection";
// import HowItWorksSection from "../HowItWorksSection";
// import TestimonialsSection from "../TestimonialsSection";
// import CTASection from "../CTASection";
// import Footer from "../Footer";
// import Feedback from "../Feedback";
// import InternshipPage from "../InternshipPage";

// // Auth Pages
// import Login from "../Login";
// import Register from "../Register";

// // Student Dashboard Components
// import StudentDashboard from "../Student/StudentDashboard";
// import ApplicationStatus from "../Student/Applicationstatus";
// import InternshipList from "../Student/InternshipList";
// import InternshipProgress from "../Student/InternshipProgress";
// import Messages from "../Student/Messages";
// import ProfilePage from "../Student/ProfilePage";
// import ResumeUpload from "../Student/ResumeUpload";
// import ApplyInternship from "../Student/ApplyInternship";

// // Company Dashboard Components
// import CompanyDashboard from "../Company/CompanyDashboard";
// import PostInternship from "../Company/PostInternship";
// import StudentResumeList from "../Company/StudentResumeList";
// import ShortlistStudents from "../Company/ShortlistStudents";
// import FeedbackStatus from "../Company/FeedbackStatus";
// import Chat from "../Company/Chat";

// // College Dashboard Components
// import CollegeDashboard from "../College/CollegeDashboard";
// import CompanyApproval from "../College/CompanyApproval";
// import InternshipMonitor from "../College/InternshipMonitor";
// import ReportAnalytics from "../College/ReportAnalytics";
// import StudentManagement from "../College/StudentManagement";

// // Landing Page Wrapper
// const Home = () => (
//   <>
//     <Navbar />
//     <HeroSection />
//     <StatsSection />
//     <CompaniesSection />
//     <InternshipsSection />
//     <HowItWorksSection />
//     <TestimonialsSection />
//     <CTASection />
//     <Footer />
//   </>
// );

// const AppRoute = () => {
//   return (
//     <Router>
//       <Routes>
//         {/* Landing Page */}
//         <Route path="/" element={<Home />} />

//         {/* Auth Routes */}
//         <Route path="/login" element={<Login />} />
//         <Route path="/register" element={<Register />} />
//         <Route path="/feedback" element={<Feedback />} />
//         <Route path="/internship" element={<InternshipPage />} />

//         {/* ================= Student Dashboard ================= */}
//         <Route path="/student-dashboard" element={<StudentDashboard />}>
//           <Route path="application-status" element={<ApplicationStatus />} />
//           <Route path="internship-list" element={<InternshipList />} />
//           <Route path="internship-progress" element={<InternshipProgress />} />
//           <Route path="messages" element={<Messages />} />
//           <Route path="profile" element={<ProfilePage />} />
//           <Route path="resume-upload" element={<ResumeUpload />} />
//           <Route path="apply-internship" element={<ApplyInternship />} />
//         </Route>

//         {/* ================= Company Dashboard ================= */}
//         <Route path="/company-dashboard" element={<CompanyDashboard />}>
//           <Route path="post-internship" element={<PostInternship />} />
//           <Route path="student-resumes" element={<StudentResumeList />} />
//           <Route path="shortlist" element={<ShortlistStudents />} />
//           <Route path="feedback" element={<FeedbackStatus />} />
//           <Route path="chat" element={<Chat />} />
//         </Route>

//         {/* ================= College Dashboard ================= */}
//         <Route path="/college-dashboard" element={<CollegeDashboard />}>
//           <Route path="company-approval" element={<CompanyApproval />} />
//           <Route path="internship-monitor" element={<InternshipMonitor />} />
//           <Route path="report-analytics" element={<ReportAnalytics />} />
//           <Route path="student-management" element={<StudentManagement />} />
//         </Route>
//       </Routes>
//     </Router>
//   );
// };

// export default AppRoute;
