// import React from "react";
// import { Link } from "react-router-dom";
// import CompanySidebar from "./CompanySidebar";

// const CompanyDashboard = () => {
//   const dashboardItems = [
//     { title: "Post Internship", link: "/company/post-internship" },
//     { title: "View Student Resumes", link: "/company/student-resumes" },
//     { title: "Shortlisted Students", link: "/company/shortlist" },
//     { title: "Feedback Status", link: "/company/feedback" },
//     { title: "Chat", link: "/company/chat" },
//   ];

//   return (
//     <div className="company-dashboard-container">
//       <h2 className="dashboard-heading">Company Dashboard</h2>
//       {/* sidebar */}
//       <CompanySidebar/>
      
      
      
      

//       <div className="dashboard-grid">
//         {dashboardItems.map((item, index) => (
//           <Link key={index} to={item.link} className="dashboard-card">
//             <h3>{item.title}</h3>
//           </Link>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default CompanyDashboard;


import React from "react";
import CompanySidebar from "./CompanySidebar";


const CompanyDashboard = () => {
  return (
    <div className="dashboard-container">
      {/* Sidebar */}
      <CompanySidebar />

      {/* Main content */}
      <main className="dashboard-content">
        {/* Welcome card */}
        <div className="welcome-card">
          <h1>Welcome to HireHub</h1>
          <p>
            Manage internships, review student applications, and communicate efficiently from your dashboard.
          </p>
        </div>

        {/* Optional Stats Section */}
        <div className="stats-grid">
          <div className="stat-card">
            <h3>Active Internships</h3>
            <p>5</p>
          </div>
          <div className="stat-card">
            <h3>Applications Received</h3>
            <p>120</p>
          </div>
          <div className="stat-card">
            <h3>Shortlisted Students</h3>
            <p>25</p>
          </div>
          <div className="stat-card">
            <h3>Messages</h3>
            <p>8</p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default CompanyDashboard;