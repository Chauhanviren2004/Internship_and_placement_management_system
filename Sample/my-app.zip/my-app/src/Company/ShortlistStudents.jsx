// import React, { useState, useEffect } from "react";
// import CompanySidebar from "./CompanySidebar";

// const ShortlistStudents = () => {
//   const [students, setStudents] = useState([]);

//   useEffect(() => {
//     const apps = JSON.parse(localStorage.getItem("applications")) || [];
//     setStudents(apps);
//   }, []);

//   return (
//     <div className="shortlist-container">
//       <h2>Shortlisted Students</h2>
//       {students.length === 0 ? (
//         <p>No applications yet.</p>
//       ) : (
//         <div className="shortlist-grid">
//           {students.map((student, index) => (
//             <div key={index} className="student-card">
//               <h3>{student.name}</h3>
//               <p><strong>Role:</strong> {student.role}</p>
//               <p><strong>Email:</strong> {student.email}</p>
//               <p><strong>Status:</strong>{" "}
//                 <span className={`status ${student.status.toLowerCase()}`}>{student.status}</span>
//               </p>
//             </div>
//           ))}
//         </div>
//       )}
//     </div>
//   );
// };

// export default ShortlistStudents;

import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";

function ShortlistStudents() {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    const data = [
      { name: "Khushi Trivedi", email: "trivedikhushi151@gmail.com", college: "SAL College", contact: "N/A", resume: "#", status: "Approved" },
      { name: "Anita Patel", email: "anita@gmail.com", college: "ABC College", contact: "9876543210", resume: "#", status: "Pending" },
      { name: "Rohit Sharma", email: "rohit@gmail.com", college: "XYZ College", contact: "9876543210", resume: "#", status: "Rejected" },
    ];
    setStudents(data);
  }, []);

  const handleStatus = (index, status) => {
    const updated = [...students];
    updated[index].status = status;
    setStudents(updated);
  };

  return (
    <div className="layout">

      {/* ✅ Sidebar */}
      <aside className="dashboard-sidebar">
        <h2 className="sidebar-logo">HireHub</h2>
        <nav className="sidebar-links">
          {/* <NavLink to="/company/dashboard" className={({ isActive }) => isActive ? "active" : ""}>Dashboard</NavLink> */}
          <NavLink to="/company/post-internship" className={({ isActive }) => isActive ? "active" : ""}>Post Internship</NavLink>
          <NavLink to="/company/student-resumes" className={({ isActive }) => isActive ? "active" : ""}>Student Resumes</NavLink>
          <NavLink to="/company/shortlist" className={({ isActive }) => isActive ? "active" : ""}>Shortlisted Students</NavLink>
          <NavLink to="/company/feedback" className={({ isActive }) => isActive ? "active" : ""}>Feedback Status</NavLink>
          <NavLink to="/company/chat" className={({ isActive }) => isActive ? "active" : ""}>Chat</NavLink>
        </nav>
      </aside>

      {/* ✅ Main Content */}
      <div className="main-content">
        <h2>Shortlisted Students</h2>
        <div className="cards-container">
          {students.map((s, i) => (
            <div className="student-card" key={i}>
              <h3>{s.name}</h3>
              <p><strong>Email:</strong> {s.email}</p>
              <p><strong>College:</strong> {s.college}</p>
              <p><strong>Contact:</strong> {s.contact}</p>
              <p>
                <strong>Resume:</strong> 
                <a href={s.resume} target="_blank" rel="noreferrer" className="resume-link">
                  View Resume
                </a>
              </p>
              <p>
                <strong>Status:</strong> 
                <span className={`status ${s.status.toLowerCase()}`}>{s.status}</span>
              </p>
              <div className="buttons">
                <button className="approve" onClick={() => handleStatus(i, "Approved")}>Approve</button>
                <button className="reject" onClick={() => handleStatus(i, "Rejected")}>Reject</button>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}

export default ShortlistStudents;