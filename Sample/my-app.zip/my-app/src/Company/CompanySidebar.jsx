// import React from "react";
// import { Link } from "react-router-dom";


// function CompanySidebar() {
//   return (
//     <div>
//       <div className="dashboard-sidebar">
//         <h2>HireHub</h2>
//         <Link to="/company-dashboard">Dashboard</Link>
//         <Link to="/post-internship">Post Internship</Link>
//         <Link to="/student-resumes">Student Resumes</Link>
//         <Link to="/shortlisted-students">Shortlisted Students</Link>
//         <Link to="/feedback-status">Feedback Status</Link>
//         <Link to="/company-chat">Chat</Link>
//       </div>
//     </div>
//   );
// }

// export default CompanySidebar;

import React from "react";
import { NavLink } from "react-router-dom"; // Use NavLink to highlight active link


const CompanySidebar = () => {
  return (
    <aside className="dashboard-sidebar">
      <h2 className="sidebar-logo">HireHub</h2>
       <h2>Dashboard</h2>
      <nav className="sidebar-links">
        {/* <NavLink to="/company/dashboard" className={({ isActive }) => isActive ? "active" : ""}>Dashboard</NavLink> */}
      
        <NavLink to="/company/post-internship" className={({ isActive }) => isActive ? "active" : ""}>Post Internship</NavLink>
        <NavLink to="/company/student-resumes" className={({ isActive }) => isActive ? "active" : ""}>Student Resumes</NavLink>
        <NavLink to="/company/shortlist" className={({ isActive }) => isActive ? "active" : ""}>Shortlisted Students</NavLink>
        <NavLink to="/company/feedback" className={({ isActive }) => isActive ? "active" : ""}>Feedback Status</NavLink>
        <NavLink to="/company/chat" className={({ isActive }) => isActive ? "active" : ""}>Chat</NavLink>
      </nav>
    </aside>
  );
};

export default CompanySidebar;
