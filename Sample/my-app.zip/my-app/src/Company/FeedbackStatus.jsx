// import React, { useState, useEffect } from "react";
// import CompanySidebar from "./CompanySidebar";

// const FeedbackStatus = () => {
//   const [feedbacks, setFeedbacks] = useState([]);

//   // Example data fetch (replace with API call)
//   useEffect(() => {
//     const fetchFeedback = async () => {
//       // TODO: Replace with API call
//       const data = [
//         { internship: "Frontend Developer", student: "Khushi Trivedi", status: "Submitted", details: "Excellent performance" },
//         { internship: "Backend Developer", student: "Rohit Sharma", status: "Pending", details: "" },
//         { internship: "UI/UX Designer", student: "Anita Patel", status: "Submitted", details: "Creative and on time" },
//       ];
//       setFeedbacks(data);
//     };
//     fetchFeedback();
//   }, []);

//   return (
//     <div className="feedback-container">
//       <h2 className="feedback-heading">Feedback Status</h2>

//       <table className="feedback-table">
//         <thead>
//           <tr>
//             <th>Internship</th>
//             <th>Student</th>
//             <th>Status</th>
//             <th>Details</th>
//           </tr>
//         </thead>
//         <tbody>
//           {feedbacks.map((fb, index) => (
//             <tr key={index} className={fb.status === "Pending" ? "pending" : "submitted"}>
//               <td>{fb.internship}</td>
//               <td>{fb.student}</td>
//               <td>{fb.status}</td>
//               <td>{fb.details || "-"}</td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// };

// export default FeedbackStatus;
import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";

function FeedbackStatus() {
  const [feedbacks, setFeedbacks] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [currentStudent, setCurrentStudent] = useState({});
  const [feedbackText, setFeedbackText] = useState("");

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem("feedbacks")) || [
      { internship: "Frontend Developer", student: "Khushi Trivedi", status: "Submitted", details: "Excellent performance" },
      { internship: "Backend Developer", student: "Rohit Sharma", status: "Pending", details: "-" },
      { internship: "UI/UX Designer", student: "Anita Patel", status: "Submitted", details: "Creative and on time" },
    ];
    setFeedbacks(data);
  }, []);

  const openForm = (student = null) => {
    if (student) {
      setCurrentStudent(student);
      setFeedbackText(student.details === "-" ? "" : student.details);
    } else {
      setCurrentStudent({ student: "", internship: "" });
      setFeedbackText("");
    }
    setShowForm(true);
  };

  const submitFeedback = () => {
    let updated;
    if (currentStudent.student) {
      updated = feedbacks.map(f =>
        f.student === currentStudent.student
          ? { ...f, details: feedbackText, status: "Submitted" }
          : f
      );
    } else {
      updated = [...feedbacks, { internship: "New Role", student: "New Student", status: "Submitted", details: feedbackText }];
    }
    setFeedbacks(updated);
    localStorage.setItem("feedbacks", JSON.stringify(updated));
    setShowForm(false);
  };

  return (
    <div className="layout">

      {/* ✅ Sidebar */}
      <aside className="dashboard-sidebar">
        <h2 className="sidebar-logo">HireHub</h2>
        <nav className="sidebar-links">
          {/* <NavLink to="/company/dashboard" className={({ isActive }) => isActive ? "active" : ""}>Dashboard</NavLink> */}
          <NavLink to="/company/post-internship" className={({ isActive }) => isActive ? "active" : ""}>Post Internship</NavLink>
          <NavLink to="/company/student-resumes" className={({ isActive }) => isActive ? "active" : ""}>Student Resumes</NavLink>
          <NavLink to="/company/shortlist" className={({ isActive }) => isActive ? "active" : ""}>Shortlisted Students</NavLink>
          <NavLink to="/company/feedback" className={({ isActive }) => isActive ? "active" : ""}>Feedback Status</NavLink>
          <NavLink to="/company/chat" className={({ isActive }) => isActive ? "active" : ""}>Chat</NavLink>
        </nav>
        <button className="sidebar-feedback-btn" onClick={() => openForm()}>Add Feedback</button>
      </aside>

      {/* ✅ Main Content */}
      <div className="main-content">
        <h2>Feedback Status</h2>
        <table>
          <thead>
            <tr>
              <th>Internship</th>
              <th>Student</th>
              <th>Status</th>
              <th>Details</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {feedbacks.map((f, i) => (
              <tr key={i}>
                <td>{f.internship}</td>
                <td>{f.student}</td>
                <td className={f.status.toLowerCase()}>{f.status}</td>
                <td>{f.details}</td>
                <td>
                  <button className="add-feedback" onClick={() => openForm(f)}>Add Feedback</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Modal */}
        {showForm && (
          <div className="modal">
            <div className="modal-content">
              <h3>Add Feedback</h3>
              {currentStudent.student && <p><strong>Student:</strong> {currentStudent.student}</p>}
              {currentStudent.internship && <p><strong>Role:</strong> {currentStudent.internship}</p>}
              <textarea
                placeholder="Enter feedback..."
                value={feedbackText}
                onChange={(e) => setFeedbackText(e.target.value)}
              ></textarea>
              <div className="modal-buttons">
                <button className="submit" onClick={submitFeedback}>Submit</button>
                <button className="cancel" onClick={() => setShowForm(false)}>Cancel</button>
              </div>
            </div>
          </div>
        )}
      </div>

    </div>
  );
}

export default FeedbackStatus;