import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";

const StudentResumeList = () => {
  const [students, setStudents] = useState([]);

  // Example data fetch (replace with API)
  useEffect(() => {
    const fetchStudents = async () => {
      const data = [
        { name: "Rahul Sharma", email: "rahul@example.com", resume: "resume-rahul.pdf" },
        { name: "Priya Patel", email: "priya@example.com", resume: "resume-priya.pdf" },
        { name: "Ankit Mehta", email: "ankit@example.com", resume: "resume-ankit.pdf" },
      ];
      setStudents(data);
    };
    fetchStudents();
  }, []);

  const handleViewResume = (resume) => {
    alert(`Open Resume: ${resume}`);
  };

  return (
    <div className="layout">

      {/* ✅ Sidebar */}
      <aside className="dashboard-sidebar">
        <h2 className="sidebar-logo">HireHub</h2>
        <nav className="sidebar-links">
          {/* <NavLink to="/company/dashboard" className={({ isActive }) => isActive ? "active" : ""}>Dashboard</NavLink> */}
          <NavLink to="/company/post-internship" className={({ isActive }) => isActive ? "active" : ""}>Post Internship</NavLink>
          <NavLink to="/company/student-resumes" className={({ isActive }) => isActive ? "active" : ""}>Student Resumes</NavLink>
          <NavLink to="/company/shortlist" className={({ isActive }) => isActive ? "active" : ""}>Shortlisted Students</NavLink>
          <NavLink to="/company/feedback" className={({ isActive }) => isActive ? "active" : ""}>Feedback Status</NavLink>
          <NavLink to="/company/chat" className={({ isActive }) => isActive ? "active" : ""}>Chat</NavLink>
        </nav>
      </aside>

      {/* ✅ Main Content */}
      <div className="main-content">
        <div className="resume-list-container">
          <h2 className="dashboard-heading">Student Resume List</h2>

          <table className="resume-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Resume</th>
              </tr>
            </thead>
            <tbody>
              {students.map((student, index) => (
                <tr key={index}>
                  <td>{student.name}</td>
                  <td>{student.email}</td>
                  <td>
                    <button
                      className="btn-view"
                      onClick={() => handleViewResume(student.resume)}
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};

export default StudentResumeList;