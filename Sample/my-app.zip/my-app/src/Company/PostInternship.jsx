import React, { useState } from "react";
import { NavLink } from "react-router-dom";

const PostInternship = () => {
  const [formData, setFormData] = useState({
    companyName: "",
    location: "",
    mode: "Online",
    duration: "",
    stipend: "",
    eligibility: "",
    openings: "",
    deadline: "",
    description: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const getStipendPlaceholder = () => {
    if (formData.mode === "Online") return "e.g., 5k/month";
    if (formData.mode === "Hybrid") return "e.g., 7k/month";
    return "e.g., 10k/month";
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const newInternship = { ...formData, status: "Pending" };

    const existing = JSON.parse(localStorage.getItem("internships")) || [];
    localStorage.setItem(
      "internships",
      JSON.stringify([...existing, newInternship])
    );

    alert("Internship sent to college for approval!");

    setFormData({
      companyName: "",
      location: "",
      mode: "Online",
      duration: "",
      stipend: "",
      eligibility: "",
      openings: "",
      deadline: "",
      description: "",
    });
  };

  return (
    <div className="layout">

      {/* ✅ Sidebar */}
      <aside className="dashboard-sidebar">
        <h2 className="sidebar-logo">HireHub</h2>
        <nav className="sidebar-links">
          {/* <NavLink to="/company/dashboard" className={({ isActive }) => isActive ? "active" : ""}>Dashboard</NavLink> */}
          <NavLink to="/company/post-internship" className={({ isActive }) => isActive ? "active" : ""}>Post Internship</NavLink>
          <NavLink to="/company/student-resumes" className={({ isActive }) => isActive ? "active" : ""}>Student Resumes</NavLink>
          <NavLink to="/company/shortlist" className={({ isActive }) => isActive ? "active" : ""}>Shortlisted Students</NavLink>
          <NavLink to="/company/feedback" className={({ isActive }) => isActive ? "active" : ""}>Feedback Status</NavLink>
          <NavLink to="/company/chat" className={({ isActive }) => isActive ? "active" : ""}>Chat</NavLink>
        </nav>
      </aside>

      {/* ✅ Main Content */}
      <div className="main-content">
        <div className="post-internship-container">
          <h2>Post New Internship</h2>

          <form className="internship-form" onSubmit={handleSubmit}>
            <input type="text" name="companyName" placeholder="Company Name"
              value={formData.companyName} onChange={handleChange} required />

            <input type="text" name="location" placeholder="Location"
              value={formData.location} onChange={handleChange} required />

            <select name="mode" value={formData.mode} onChange={handleChange}>
              <option value="Online">Online</option>
              <option value="Offline">Offline</option>
              <option value="Hybrid">Hybrid</option>
            </select>

            <input type="text" name="duration" placeholder="Duration (e.g., 3 months)"
              value={formData.duration} onChange={handleChange} required />

            <input type="text" name="stipend" placeholder={getStipendPlaceholder()}
              value={formData.stipend} onChange={handleChange} required />

            <input type="text" name="eligibility" placeholder="Eligibility"
              value={formData.eligibility} onChange={handleChange} required />

            <input type="number" name="openings" placeholder="Openings"
              value={formData.openings} onChange={handleChange} required />

            <input type="date" name="deadline"
              value={formData.deadline} onChange={handleChange} required />

            <textarea name="description" placeholder="Description / Responsibilities"
              value={formData.description} onChange={handleChange} rows={4} required />

            <button type="submit" className="submit-btn">
              Post Internship
            </button>
          </form>
        </div>
      </div>

    </div>
  );
};

export default PostInternship;