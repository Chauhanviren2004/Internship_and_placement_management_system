import React, { useState, useRef, useEffect } from "react";
import { NavLink } from "react-router-dom";

const Chat = () => {
  const [messages, setMessages] = useState([]);
  const [selectedQuestion, setSelectedQuestion] = useState("");
  const chatEndRef = useRef(null);

  // Questions + Answers
  const qaList = [
    { q: "Tell me about yourself.", a: "I am a motivated student with strong interest in web development and problem solving." },
    { q: "What are your strengths?", a: "My strengths are quick learning, teamwork, and strong problem-solving skills." },
    { q: "What are your weaknesses?", a: "Sometimes I focus too much on details, but I am learning to manage time efficiently." },
    { q: "Why do you want this internship?", a: "I want to gain real-world experience and improve my technical skills." },
    { q: "What skills do you have?", a: "I have skills in React, JavaScript, HTML, CSS, and basic backend knowledge." },
    { q: "Do you have any project experience?", a: "Yes, I have worked on projects like a weather app and expense tracker using React." },
    { q: "Are you comfortable with deadlines?", a: "Yes, I can manage my work efficiently and meet deadlines." },
    { q: "Why should we hire you?", a: "I am dedicated, quick learner, and passionate about improving my skills." },
    { q: "What technologies do you know?", a: "I know React, Node.js basics, JavaScript, and Bootstrap." },
    { q: "Are you open to relocation?", a: "Yes, I am open to relocation for better opportunities." },
    { q: "What are your career goals?", a: "I want to become a skilled full-stack developer." },
    { q: "Do you have any questions for us?", a: "Yes, I would like to know about growth opportunities in your company." }
  ];

  // Auto scroll
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSelect = (e) => {
    const question = e.target.value;
    setSelectedQuestion(question);
    if (question === "") return;
    const selectedQA = qaList.find((item) => item.q === question);

    // Add company question
    setMessages((prev) => [
      ...prev,
      { sender: "Company", text: selectedQA.q }
    ]);

    // Add student answer after delay
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        { sender: "Student", text: selectedQA.a }
      ]);
    }, 1000);
  };

  return (
    <div className="layout">

      {/* ✅ Sidebar */}
      <aside className="dashboard-sidebar">
        <h2 className="sidebar-logo">HireHub</h2>
        <nav className="sidebar-links">
          {/* <NavLink to="/company/dashboard" className={({ isActive }) => isActive ? "active" : ""}>Dashboard</NavLink> */}
          <NavLink to="/company/post-internship" className={({ isActive }) => isActive ? "active" : ""}>Post Internship</NavLink>
          <NavLink to="/company/student-resumes" className={({ isActive }) => isActive ? "active" : ""}>Student Resumes</NavLink>
          <NavLink to="/company/shortlist" className={({ isActive }) => isActive ? "active" : ""}>Shortlisted Students</NavLink>
          <NavLink to="/company/feedback" className={({ isActive }) => isActive ? "active" : ""}>Feedback Status</NavLink>
          <NavLink to="/company/chat" className={({ isActive }) => isActive ? "active" : ""}>Chat</NavLink>
        </nav>
      </aside>

      {/* ✅ Main Content */}
      <div className="main-content">
        <h2>Company Interview Chat</h2>

        {/* Dropdown */}
        <div className="dropdown-box">
          <select value={selectedQuestion} onChange={handleSelect}>
            <option value="">-- Ask a Question --</option>
            {qaList.map((item, index) => (
              <option key={index} value={item.q}>{item.q}</option>
            ))}
          </select>
        </div>

        {/* Chat UI */}
        <div className="chat-box">
          {messages.length === 0 && (
            <p className="no-chat">Start interview by asking a question.</p>
          )}

          {messages.map((msg, index) => (
            <div
              key={index}
              className={`chat-message ${msg.sender === "Company" ? "company-msg" : "student-msg"}`}
            >
              <strong>{msg.sender}:</strong> {msg.text}
            </div>
          ))}
          <div ref={chatEndRef}></div>
        </div>
      </div>
    </div>
  );
};

export default Chat;