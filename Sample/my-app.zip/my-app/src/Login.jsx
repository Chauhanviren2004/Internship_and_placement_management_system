



// import React, { useState } from "react";
// import { Briefcase, Mail, Lock, ArrowLeft } from "lucide-react";
// import { Link, useNavigate } from "react-router-dom";
// import axios from "axios";
// import "./Auth.css";

// const Login = () => {
//   const navigate = useNavigate();

//   const [loginData, setLoginData] = useState({
//     email: "",
//     password: "",
//   });

//   // Handle input
//   const handleChange = (e) => {
//     setLoginData({
//       ...loginData,
//       [e.target.name]: e.target.value,
//     });
//   };

//   // Handle login
//   const handleLogin = (e) => {
//     // e.preventDefault(); // ✅ prevent refresh

//     axios
//       .post("http://127.0.0.1:8000/student/login", loginData)
//       .then((res) => {
//         console.log("Login Success:", res.data);

//         // Redirect
//         navigate("/student-dashboard");
//       })
//       .catch((err) => {
//         console.log("Login Error:", err.response?.data || err.message);
//       });
//   };

//   return (
//     <div className="auth-page">
//       <div className="auth-left-panel">
//         <div className="auth-glow-overlay"></div>
//         <div className="auth-branding">
//           <div className="auth-logo">
//             <Briefcase size={40} className="teal-icon" />
//             <span className="logo-name">HireHub</span>
//           </div>
//           <h1 className="auth-hero-text">Welcome Back!</h1>
//         </div>
//       </div>

//       <div className="auth-right-panel">
//         <div className="form-container">
//           <Link to="/" className="back-home-btn">
//             <ArrowLeft size={16} /> Back to home
//           </Link>

//           <h2 className="form-title">Sign In</h2>

//           {/* Email */}
//           <div className="input-group">
//             <label>Email Address</label>
//             <div className="input-wrapper">
//               <Mail size={18} />
//               <input
//                 type="email"
//                 name="email"
//                 placeholder=""
//                 required
//                 value={loginData.email}
//                 onChange={handleChange}
//               />
//             </div>
//           </div>

//           {/* Password */}
//           <div className="input-group">
//             <label>Password</label>
//             <div className="input-wrapper">
//               <Lock size={18} />
//               <input
//                 type="password"
//                 name="password"
//                 placeholder=""

//                 required
//                 value={loginData.password}
//                 onChange={handleChange}
//               />
//             </div>
//           </div>

//           {/* Button */}
//           <button className="submit-btn" onClick={handleLogin}>
//             Sign In
//           </button>

//           <p className="toggle-mode-text">
//             New to HireHub? <Link to="/Register">Create an account</Link>
//           </p>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Login;




// import React from "react";
// import { Briefcase, Mail, Lock, ArrowLeft } from "lucide-react";
// import { Link, useNavigate } from "react-router-dom";
// import "./Auth.css";

// const Login = () => {
//   const navigate = useNavigate();

//   const handleLogin = (e) => {
//     e.preventDefault();

//     // TEMP LOGIC (replace with backend later)
//     const role = "student"; // change dynamically later

//     if (role === "student") navigate("/student-dashboard");
//     if (role === "company") navigate("/company-dashboard");
//     if (role === "admin") navigate("/admin-dashboard");
//   };

//   return (
//     <div className="auth-page">
//       {/* LEFT */}
//       <div className="auth-left-panel">
//         <div className="auth-branding">
//           <div className="auth-logo">
//             <Briefcase size={32} />
//             <span>HireHub</span>
//           </div>

//           <h1>Welcome Back!</h1>
//           <p>
//             Log in to track your applications and discover new opportunities.
//           </p>
//         </div>
//       </div>

//       {/* RIGHT */}
//       <div className="auth-right-panel">
//         <div className="form-container">
//           <Link to="/" className="back-home-btn">
//             <ArrowLeft size={16} /> Back to home
//           </Link>

//           <h2>Sign In</h2>

//           <form onSubmit={handleLogin}>
//             <div className="input-group">
//               <label>EMAIL ADDRESS</label>
//               <div className="input-wrapper">
//                 <Mail size={18} />
//                 <input type="email" required />
//               </div>
//             </div>

//             <div className="input-group">
//               <label>PASSWORD</label>
//               <div className="input-wrapper">
//                 <Lock size={18} />
//                 <input type="password" required />
//               </div>
//             </div>

//             <button className="submit-btn">Sign In</button>
//           </form>

//           <p className="bottom-text">
//             New to HireHub? <Link to="/register">Create an account</Link>
//           </p>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Login;





import React, { useState } from "react";
import { Briefcase, Mail, Lock, ArrowLeft } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import "./Auth.css";

const Login = () => {
  const navigate = useNavigate();
  const [role, setRole] = useState("student");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async (e) => {
    e.preventDefault();

    let url = "";
    if (role === "student") url = "http://127.0.0.1:8000/student/login";
    if (role === "company") url = "http://127.0.0.1:8000/company/login";
    if (role === "admin") url = "http://127.0.0.1:8000/admin/login";

    try {
      const response = await axios.post(url, { email, password });

      console.log("Login Response:", response.data);

      console.log("Stored User:", localStorage.getItem("user"));

      if (response.status === 200) {
        alert("Login Successful ✅");

        // ✅ Store ONLY user object in localStorage
        localStorage.setItem("user", JSON.stringify(response.data.user));

        console.log("User stored in localStorage:", localStorage.getItem("user"));

        // Store token if backend sends it
        if (response.data.token) localStorage.setItem("token", response.data.token);

        // Redirect
        if (role === "student") navigate("/student-dashboard");
        if (role === "company") navigate("/company-dashboard");
        if (role === "admin") navigate("/admin-dashboard");
      }
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.detail || "Invalid credentials!");
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-left-panel">
        <div className="auth-branding">
          <div className="auth-logo">
            <Briefcase size={32} />
            <span>HireHub</span>
          </div>
          <h1>Welcome Back!</h1>
          <p>Log in to track your applications and discover new opportunities.</p>
        </div>
      </div>

      <div className="auth-right-panel">
        <div className="form-container">
          <Link to="/" className="back-home-btn">
            <ArrowLeft size={16} /> Back to home
          </Link>

          <h2>Sign In</h2>

          <form onSubmit={handleLogin}>
            <div className="input-group">
              <label>I AM A</label>
              <div className="role-selector">
                <button
                  type="button"
                  className={role === "student" ? "active" : ""}
                  onClick={() => setRole("student")}
                >
                  🎓 Student
                </button>
                <button
                  type="button"
                  className={role === "company" ? "active" : ""}
                  onClick={() => setRole("company")}
                >
                  🏢 Company
                </button>
                <button
                  type="button"
                  className={role === "admin" ? "active" : ""}
                  onClick={() => setRole("admin")}
                >
                  🛡 Admin
                </button>
              </div>
            </div>

            <div className="input-group">
              <label>EMAIL ADDRESS</label>
              <div className="input-wrapper">
                <Mail size={18} />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="input-group">
              <label>PASSWORD</label>
              <div className="input-wrapper">
                <Lock size={18} />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            </div>

            <button className="submit-btn">Sign In</button>
          </form>

          <p className="bottom-text">
            New to HireHub? <Link to="/register">Create an account</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;