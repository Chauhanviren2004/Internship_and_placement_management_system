import React from "react";

import { Link } from "react-router-dom";

function Sidebar() {
  return (
    <div>
      <div className="dashboard-sidebar">
        <h2>HireHub</h2>
        <Link to="/profile">Profile</Link>
        <Link to="/internship-list">Available Internships</Link>
        <Link to="/application-status">Applications</Link>
        <Link to="/messages">Messages</Link>
        <Link to="/resume-upload">Upload Resume</Link>
      </div>
       
    </div>
       

    
  );
}

export default Sidebar;
