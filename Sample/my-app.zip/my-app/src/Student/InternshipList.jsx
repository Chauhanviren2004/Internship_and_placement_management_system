// import React, { useState } from 'react';
// import Sidebar from './Sidebar';

// const internships = [
//   { id: 1, company: "TechNova", role: "Frontend Intern", location: "Ahmedabad", stipend: "₹10,000" },
//   { id: 2, company: "InnoSoft", role: "React Intern", location: "Gandhinagar", stipend: "₹12,000" },
//   { id: 3, company: "DataSolutions", role: "Data Analyst Intern", location: "Ahmedabad", stipend: "₹15,000" },
//   { id: 4, company: "WebWorks", role: "Fullstack Intern", location: "Surat", stipend: "₹14,000" },
// ];

// const InternshipList = () => {
//   const [search, setSearch] = useState("");
//   const [filterLocation, setFilterLocation] = useState("All");

//   const filteredInternships = internships
//     .filter(i => 
//       (filterLocation === "All" || i.location === filterLocation) &&
//       (i.role.toLowerCase().includes(search.toLowerCase()) || i.company.toLowerCase().includes(search.toLowerCase()))
//     );

//   const locations = ["All", ...new Set(internships.map(i => i.location))];

//   return (


//     <>
     
//        <div className="internship-list-container">
//       <h4 className="section-title">Available Internships</h4>
     
//       {/* Filters */}
//       <div className="filters-bar">
//         <input 
//           type="text" 
//           placeholder="Search by role or company..." 
//           value={search} 
//           onChange={(e) => setSearch(e.target.value)}
//         />
//         <select value={filterLocation} onChange={(e) => setFilterLocation(e.target.value)}>
//           {locations.map(loc => <option key={loc} value={loc}>{loc}</option>)}
//         </select>
//       </div>

//       {/* Internship Cards */}
//       <div className="internship-cards">
//         {filteredInternships.length === 0 && <p className="no-internships">No internships found.</p>}

//         {filteredInternships.map(i => (
//           <div className="internship-card" key={i.id}>
//             <h5 className="internship-role">{i.role}</h5>
//             <p className="internship-company">{i.company}</p>
//             <p className="internship-location">{i.location}</p>
//             <p className="internship-stipend">{i.stipend}</p>
//             <button className="apply-btn">Apply Now</button>
//           </div>
//         ))}
//       </div>
//     </div>
//     </>
//   );
// };

// export default InternshipList;
import React, { useState, useEffect } from 'react';
import Sidebar from './Sidebar';

const InternshipList = () => {
  const [search, setSearch] = useState("");
  const [filterLocation, setFilterLocation] = useState("All");
  const [internships, setInternships] = useState([]);

  // Application form state
  const [showForm, setShowForm] = useState(false);
  const [selectedInternship, setSelectedInternship] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    college: "",
    reason: ""
  });

  // Fetch approved internships from localStorage on mount
  useEffect(() => {
    const data = JSON.parse(localStorage.getItem("internships")) || [];
    const approved = data.filter(i => i.status === "Approved");
    setInternships(approved);
  }, []);

  const locations = ["All", ...new Set(internships.map(i => i.location))];

  // Safe filtering to prevent toLowerCase errors
  const filteredInternships = internships.filter(i =>
    (filterLocation === "All" || i.location === filterLocation) &&
    ((i.role || "").toLowerCase().includes(search.toLowerCase()) ||
     (i.company || "").toLowerCase().includes(search.toLowerCase()))
  );

  const handleApplyClick = (internship) => {
    setSelectedInternship(internship);
    setShowForm(true);
  };

  const handleClose = () => {
    setShowForm(false);
    setFormData({ name: "", email: "", phone: "", college: "", reason: "" });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!formData.name || !formData.email || !formData.phone) {
      alert("Please fill all required fields.");
      return;
    }

    const newApplication = {
      ...formData,
      role: selectedInternship.role,
      company: selectedInternship.company,
      date: new Date().toLocaleDateString(),
      status: "Pending"
    };

    // Save application in localStorage
    const existingApps = JSON.parse(localStorage.getItem("applications")) || [];
    localStorage.setItem("applications", JSON.stringify([...existingApps, newApplication]));

    alert("Application submitted successfully!");

    handleClose();
  };

  return (
    <>
      <Sidebar />

      <div className="internship-list-container">
        <h4 className="section-title">Available Internships</h4>

        {/* Filters */}
        <div className="filters-bar">
          <input
            type="text"
            placeholder="Search by role or company..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <select
            value={filterLocation}
            onChange={(e) => setFilterLocation(e.target.value)}
          >
            {locations.map(loc => (
              <option key={loc}>{loc}</option>
            ))}
          </select>
        </div>

        {/* Internship Cards */}
        <div className="internship-cards">
          {filteredInternships.length === 0 && <p>No internships found.</p>}

          {filteredInternships.map((i, index) => (
            <div className="internship-card" key={index}>
              <h5 className="internship-role">{i.role}</h5>
              <p>{i.company}</p>
              <p>{i.location}</p>
              <p>{i.stipend}</p>

              <button
                className="apply-btn"
                onClick={() => handleApplyClick(i)}
              >
                Apply Now
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Application Form Modal */}
      {showForm && selectedInternship && (
        <div className="apply-modal">
          <div className="apply-form">
            <h3>Apply for {selectedInternship.role}</h3>

            <form onSubmit={handleSubmit}>
              <input
                type="text"
                name="name"
                placeholder="Full Name"
                value={formData.name}
                onChange={handleChange}
                required
              />
              <input
                type="email"
                name="email"
                placeholder="Email"
                value={formData.email}
                onChange={handleChange}
                required
              />
              <input
                type="text"
                name="phone"
                placeholder="Phone Number"
                value={formData.phone}
                onChange={handleChange}
                required
              />
              <input
                type="text"
                name="college"
                placeholder="College Name"
                value={formData.college}
                onChange={handleChange}
              />
              <textarea
                name="reason"
                placeholder="Why are you suitable for this internship?"
                value={formData.reason}
                onChange={handleChange}
              />

              <button type="submit" className="submit-btn">
                Submit Application
              </button>
              <button type="button" className="close-btn" onClick={handleClose}>
                Close
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default InternshipList;