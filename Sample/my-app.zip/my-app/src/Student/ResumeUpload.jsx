// import React, { useState } from "react";
// import Sidebar from "./Sidebar";

// const ResumeUpload = () => {
//   const [file, setFile] = useState(null);
//   const [message, setMessage] = useState("");
//   const [messageType, setMessageType] = useState(""); // "success" or "error"

//   const handleFileChange = (e) => {
//     const selectedFile = e.target.files[0];
//     if (!selectedFile) return;

//     const validTypes = [
//       "application/pdf",
//       "application/msword",
//       "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
//     ];

//     if (!validTypes.includes(selectedFile.type)) {
//       setMessage("Only PDF or Word files are allowed!");
//       setMessageType("error");
//       setFile(null);
//       return;
//     }

//     setFile(selectedFile);
//     setMessage("");
//     setMessageType("");
//   };

//   const handleUpload = () => {
//     if (!file) {
//       setMessage("Please select a file first!");
//       setMessageType("error");
//       return;
//     }

//     // TODO: Replace with actual API call
//     console.log("Uploading file:", file);

//     setMessage(`File "${file.name}" uploaded successfully!`);
//     setMessageType("success");
//     setFile(null);
//   };

//   return (
//     <>
//     <Sidebar/>

//     <div className="resume-container">
//       <h2>Upload Your Resume</h2>

//       <input
//         type="file"
//         accept=".pdf,.doc,.docx"
//         onChange={handleFileChange}
//       />

//       {file && (
//         <div className="resume-preview">
//           Selected File: {file.name}
//         </div>
//       )}

//       {message && (
//         <div
//           className={`resume-message ${
//             messageType === "success" ? "success" : "error"
//           }`}
//         >
//           {message}
//         </div>
//       )}

//       <button className="resume-button" onClick={handleUpload}>
//         Upload Resume
//       </button>
//     </div>
//     </>
//   );
// };

// export default ResumeUpload;


// import React, { useState } from "react";
// import Sidebar from "./Sidebar";
// import axios from "axios";

// const ResumeUpload = () => {
//   const [file, setFile] = useState(null);
//   const [message, setMessage] = useState("");
//   const [messageType, setMessageType] = useState(""); // "success" or "error"

//   // Replace with actual student id from localStorage or auth
//   const studentId = JSON.parse(localStorage.getItem("user"))?.id;

//   const handleFileChange = (e) => {
//     const selectedFile = e.target.files[0];
//     if (!selectedFile) return;

//     const validTypes = [
//       "application/pdf",
//       "application/msword",
//       "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
//     ];

//     if (!validTypes.includes(selectedFile.type)) {
//       setMessage("Only PDF or Word files are allowed!");
//       setMessageType("error");
//       setFile(null);
//       return;
//     }

//     setFile(selectedFile);
//     setMessage("");
//     setMessageType("");
//   };

//   const handleUpload = () => {
//     if (!file) {
//       setMessage("Please select a file first!");
//       setMessageType("error");
//       return;
//     }

//     // Create FormData to send file
//     const formData = new FormData();
//     formData.append("resume", file);

//     axios
//       .put(`http://127.0.0.1:8000/student/upload_resume/${studentId}`, formData, {
//         headers: {
//           "Content-Type": "multipart/form-data",
//         },
//       })
//       .then((res) => {
//         console.log("Upload Success:", res.data);
//         setMessage(`File "${file.name}" uploaded successfully!`);
//         setMessageType("success");
//         setFile(null);
//       })
//       .catch((err) => {
//         console.log("Upload Error:", err.response?.data || err.message);
//         setMessage("Failed to upload file. Please try again.");
//         setMessageType("error");
//       });
//   };

//   return (
//     <>
//       <Sidebar />

//       <div className="resume-container">
//         <h2>Upload Your Resume</h2>

//         <input type="file" accept=".pdf,.doc,.docx" onChange={handleFileChange} />

//         {file && (
//           <div className="resume-preview">Selected File: {file.name}</div>
//         )}

//         {message && (
//           <div className={`resume-message ${messageType === "success" ? "success" : "error"}`}>
//             {message}
//           </div>
//         )}

//         <button className="resume-button" onClick={handleUpload}>
//           Upload Resume
//         </button>
//       </div>
//     </>
//   );
// };

// export default ResumeUpload;



// import React, { useState } from "react";
// import Sidebar from "./Sidebar";
// import axios from "axios";

// const ResumeUpload = () => {
//   const [file, setFile] = useState(null);
//   const [uploadedFile, setUploadedFile] = useState(null); // store uploaded file info
//   const [message, setMessage] = useState("");
//   const [messageType, setMessageType] = useState(""); // "success" or "error"

//   const studentId = JSON.parse(localStorage.getItem("user"))?.id;

//   const handleFileChange = (e) => {
//     const selectedFile = e.target.files[0];
//     if (!selectedFile) return;

//     const validTypes = [
//       "application/pdf",
//       "application/msword",
//       "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
//     ];

//     if (!validTypes.includes(selectedFile.type)) {
//       setMessage("Only PDF or Word files are allowed!");
//       setMessageType("error");
//       setFile(null);
//       return;
//     }

//     setFile(selectedFile);
//     setMessage("");
//     setMessageType("");
//   };

//   const handleUpload = () => {
//     if (!file) {
//       setMessage("Please select a file first!");
//       setMessageType("error");
//       return;
//     }

//     const formData = new FormData();
//     formData.append("resume", file);

//     axios
//       .put(`http://127.0.0.1:8000/student/upload_resume/${studentId}`, formData, {
//         headers: { "Content-Type": "multipart/form-data" },
//       })
//       .then((res) => {
//         console.log("Upload Success:", res.data);
//         setMessage(`File "${file.name}" uploaded successfully!`);
//         setMessageType("success");

//         // Store uploaded file info from backend
//         setUploadedFile({
//           name: file.name,
//           url: `http://127.0.0.1:8000/${res.data.resume}`, // Make sure your backend serves static files
//         });

//         setFile(null);
//       })
//       .catch((err) => {
//         console.log("Upload Error:", err.response?.data || err.message);
//         setMessage("Failed to upload file. Please try again.");
//         setMessageType("error");
//       });
//   };

//   return (
//     <>
//       <Sidebar />

//       <div className="resume-container">
//         <h2>Upload Your Resume</h2>

//         <input type="file" accept=".pdf,.doc,.docx" onChange={handleFileChange} />

//         {file && <div className="resume-preview">Selected File: {file.name}</div>}

//         {uploadedFile && (
//           <div className="resume-preview">
//             Uploaded File:{" "}
//             <a href={uploadedFile.url} target="_blank" rel="noopener noreferrer">
//               {uploadedFile.name}
//             </a>
//           </div>
//         )}

//         {message && (
//           <div className={`resume-message ${messageType === "success" ? "success" : "error"}`}>
//             {message}
//           </div>
//         )}

//         <button className="resume-button" onClick={handleUpload}>
//           Upload Resume
//         </button>
//       </div>
//     </>
//   );
// };

// export default ResumeUpload;



// import React, { useState } from "react";
// import Sidebar from "./Sidebar";
// import axios from "axios";

// const ResumeUpload = () => {
//   const [file, setFile] = useState(null);
//   const [message, setMessage] = useState("");
//   const [messageType, setMessageType] = useState(""); // "success" or "error"
//   const [resumeLink, setResumeLink] = useState(null);

//   // Get studentId from localStorage (make sure it's stored after login)
//   const studentId = JSON.parse(localStorage.getItem("user"))?._id;

//   console.log("User from localStorage:", JSON.parse(localStorage.getItem("user")));

//   const handleFileChange = (e) => {
//     const selectedFile = e.target.files[0];
//     if (!selectedFile) return;

//     const validTypes = [
//       "application/pdf",
//       "application/msword",
//       "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
//     ];

//     if (!validTypes.includes(selectedFile.type)) {
//       setMessage("Only PDF or Word files are allowed!");
//       setMessageType("error");
//       setFile(null);
//       return;
//     }

//     setFile(selectedFile);
//     setMessage("");
//     setMessageType("");
//   };

//   const handleUpload = () => {
//     if (!file) {
//       setMessage("Please select a file first!");
//       setMessageType("error");
//       return;
//     }

//     if (!studentId) {
//       setMessage("Student ID missing! Please login again.");
//       setMessageType("error");
//       return;
//     }

//     const formData = new FormData();
//     formData.append("resume", file);

//     axios
//       .put(`http://127.0.0.1:8000/student/upload_resume/${studentId}`, formData, {
//         headers: { "Content-Type": "multipart/form-data" },
//       })
//       .then((res) => {
//         console.log("Upload Success:", res.data);
//         setMessage(`File "${file.name}" uploaded successfully!`);
//         setMessageType("success");

//         // Save uploaded file info
//         setResumeLink({
//           name: file.name,
//           url: res.data.resume_url, // must match backend response
//         });

//         setFile(null);
//       })
//       .catch((err) => {
//         console.log("Upload Error:", err.response?.data || err.message);
//         setMessage("Failed to upload file. Please try again.");
//         setMessageType("error");
//       });
//   };

//   return (
//     <>
//       <Sidebar />
//       <div className="resume-container">
//         <h2>Upload Your Resume</h2>

//         <input type="file" accept=".pdf,.doc,.docx" onChange={handleFileChange} />

//         {file && <div className="resume-preview">Selected File: {file.name}</div>}

//         {resumeLink && (
//           <div className="resume-link">
//             Uploaded File:{" "}
//             <a href={resumeLink.url} target="_blank" rel="noopener noreferrer">
//               {resumeLink.name}
//             </a>
//           </div>
//         )}

//         {message && (
//           <div className={`resume-message ${messageType === "success" ? "success" : "error"}`}>
//             {message}
//           </div>
//         )}

//         <button className="resume-button" onClick={handleUpload}>
//           Upload Resume
//         </button>
//       </div>
//     </>
//   );
// };

// export default ResumeUpload;


// import React, { useState } from "react";
// import Sidebar from "./Sidebar";
// import axios from "axios";

// const ResumeUpload = () => {
//   const [file, setFile] = useState(null);
//   const [message, setMessage] = useState("");
//   const [messageType, setMessageType] = useState("");
//   const [resumeLink, setResumeLink] = useState(null);

//   // ✅ SAFE USER FETCH
//   const user = JSON.parse(localStorage.getItem("user") || "null");

//   const studentId = user?._id || user?.id || user?.studentId;

//   const handleFileChange = (e) => {
//     const selectedFile = e.target.files[0];
//     if (!selectedFile) return;

//     const validTypes = [
//       "application/pdf",
//       "application/msword",
//       "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
//     ];

//     if (!validTypes.includes(selectedFile.type)) {
//       setMessage("Only PDF or Word files are allowed!");
//       setMessageType("error");
//       setFile(null);
//       return;
//     }

//     setFile(selectedFile);
//     setMessage("");
//     setMessageType("");
//   };

//   const handleUpload = async () => {
//     // ✅ CHECK LOGIN FIRST
//     if (!user) {
//       setMessage("User not logged in! Please login again.");
//       setMessageType("error");
//       return;
//     }

//     if (!studentId) {
//       setMessage("Student ID missing! Please login again.");
//       setMessageType("error");
//       return;
//     }

//     if (!file) {
//       setMessage("Please select a file first!");
//       setMessageType("error");
//       return;
//     }

//     try {
//       const formData = new FormData();
//       formData.append("resume", file);

//       const res = await axios.put(
//         `http://127.0.0.1:8000/student/upload_resume/${studentId}`,
//         formData,
//         {
//           headers: { "Content-Type": "multipart/form-data" },
//         }
//       );

//       console.log("Upload Success:", res.data);

//       setMessage(`File "${file.name}" uploaded successfully!`);
//       setMessageType("success");

//       setResumeLink({
//         name: file.name,
//         url: res.data.resume_url,
//       });

//       setFile(null);
//     } catch (err) {
//       console.log("Upload Error:", err.response?.data || err.message);
//       setMessage("Failed to upload file. Please try again.");
//       setMessageType("error");
//     }
//   };

//   return (
//     <>
//       <Sidebar />
//       <div className="resume-container">
//         <h2>Upload Your Resume</h2>

//         <input type="file" accept=".pdf,.doc,.docx" onChange={handleFileChange} />

//         {file && <div className="resume-preview">Selected File: {file.name}</div>}

//         {resumeLink && (
//           <div className="resume-link">
//             Uploaded File:{" "}
//             <a href={resumeLink.url} target="_blank" rel="noopener noreferrer">
//               {resumeLink.name}
//             </a>
//           </div>
//         )}

//         {message && (
//           <div className={`resume-message ${messageType}`}>
//             {message}
//           </div>
//         )}

//         <button className="resume-button" onClick={handleUpload}>
//           Upload Resume
//         </button>
//       </div>
//     </>
//   );
// };

// export default ResumeUpload;


import React, { useState, useEffect } from "react";
import Sidebar from "./Sidebar";
import axios from "axios";

const ResumeUpload = () => {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState("");
  const [resumeLink, setResumeLink] = useState(null);
  const [studentId, setStudentId] = useState(null);

  // ✅ Fetch user safely on mount
  // useEffect(() => {
  //   const storedUser = JSON.parse(localStorage.getItem("user") || "null");
  //   if (storedUser && storedUser._id) {
  //     setStudentId(storedUser._id);
  //   } else {
  //     setMessage("Student ID missing! Please login again.");
  //     setMessageType("error");
  //   }
  // }, []);

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user") || "null");
    console.log("Stored user on mount:", storedUser);
    if (storedUser && storedUser._id) {
      setStudentId(storedUser._id);
    } else {
      setMessage("Student ID missing! Please login again.");
      setMessageType("error");
    }
  }, []);

  console.log("Student ID:", studentId);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (!selectedFile) return;

    const validTypes = [
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ];

    if (!validTypes.includes(selectedFile.type)) {
      setMessage("Only PDF or Word files are allowed!");
      setMessageType("error");
      setFile(null);
      return;
    }

    setFile(selectedFile);
    setMessage("");
    setMessageType("");
  };

  const handleUpload = async () => {
    if (!studentId) {
      setMessage("Student ID missing! Please login again.");
      setMessageType("error");
      return;
    }

    if (!file) {
      setMessage("Please select a file first!");
      setMessageType("error");
      return;
    }

    try {
      const formData = new FormData();
      formData.append("resume", file);

      const res = await axios.put(
        `http://127.0.0.1:8000/student/upload_resume/${studentId}`,
        formData,
        { headers: { "Content-Type": "multipart/form-data" } }
      );

      console.log("Upload Success:", res.data);

      setMessage(`File "${file.name}" uploaded successfully!`);
      setMessageType("success");

      setResumeLink({
        name: file.name,
        url: res.data.resume_url,
      });

      setFile(null);
    } catch (err) {
      console.log("Upload Error:", err.response?.data || err.message);
      setMessage("Failed to upload file. Please try again.");
      setMessageType("error");
    }
  };

  return (
    <>
      <Sidebar />
      <div className="resume-container">
        <h2>Upload Your Resume</h2>

        <input type="file" accept=".pdf,.doc,.docx" onChange={handleFileChange} />

        {file && <div className="resume-preview">Selected File: {file.name}</div>}

        {resumeLink && (
          <div className="resume-link">
            Uploaded File:{" "}
            <a href={resumeLink.url} target="_blank" rel="noopener noreferrer">
              {resumeLink.name}
            </a>
          </div>
        )}

        {message && <div className={`resume-message ${messageType}`}>{message}</div>}

        <button className="resume-button" onClick={handleUpload}>
          Upload Resume
        </button>
      </div>
    </>
  );
};

export default ResumeUpload;