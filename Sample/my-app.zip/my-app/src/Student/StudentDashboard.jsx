// import React, { useState, useEffect } from "react";
// import { Link, Outlet } from "react-router-dom";

// const StudentDashboard = () => {
//   const [progress, setProgress] = useState(45); // example internship progress

//   // Simulate dynamic progress update
//   useEffect(() => {
//     const interval = setInterval(() => {
//       setProgress((prev) => (prev < 80 ? prev + 5 : prev));
//     }, 2000);
//     return () => clearInterval(interval);
//   }, []);

//   return (
//     <div className="dashboard-container">

//       {/* Sidebar */}
//       <div className="dashboard-sidebar">
//         <h2>HireHub</h2>
//         <Link to="/profile">Profile</Link>
//         <Link to="/internship-list">Available Internships</Link>
//         <Link to="/application-status">Applications</Link>
//         <Link to="/messages">Messages</Link>
//         <Link to="/resume-upload">Upload Resume</Link>
//       </div>

//       {/* Main Content */}
//       <div className="dashboard-content">
//         {/* Example Cards */}
//         <div className="dashboard-card">
//           <h3>Welcome, Khushi!</h3>
//           <p>Here is your student dashboard overview.</p>
//         </div>

//         {/* <div className="dashboard-card">
//           <h3>Internship Progress</h3>
//           <p>Overall progress of your ongoing internships:</p>
//           <div className="progress-bar-container">
//             <div
//               className="progress-bar"
//               style={{ width: `${progress}%` }}
//             ></div>
//           </div>
//           <p>{progress}% completed</p>
//         </div>

//         <div className="dashboard-card">
//           <h3>Next Steps</h3>
//           <ul>
//             <li>Apply for new internships</li>
//             <li>Upload/Update your resume</li>
//             <li>Check your application status</li>
//             <li>Message companies for updates</li>
//           </ul>
//         </div> */}

//         {/* Outlet for nested routes if needed */}
//         <Outlet />
//       </div>
//     </div>
//   );
// };

// export default StudentDashboard;


import React, { useState, useEffect } from "react";
import { Link, Outlet } from "react-router-dom";

const StudentDashboard = () => {
  const [progress, setProgress] = useState(45); // example internship progress

  // Simulate dynamic progress update
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => (prev < 80 ? prev + 5 : prev));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="dashboard-container">
      {/* Sidebar */}
      <aside className="dashboard-sidebar">
        <h2 className="sidebar-logo">HireHub</h2>
        <nav className="sidebar-links">
          <Link to="/profile">Profile</Link>
          <Link to="/internship-list">Available Internships</Link>
          <Link to="/application-status">Applications</Link>
          <Link to="/messages">Messages</Link>
          <Link to="/resume-upload">Upload Resume</Link>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="dashboard-content">
        {/* Welcome Card */}
        <div className="dashboard-card welcome-card">
          <h1>Welcome, Khushi!</h1>
          <p className="welcome-subtext">
            Here is your student dashboard overview.
          </p>
        </div>

        {/* Example Progress Card
        <div className="dashboard-card progress-card">
          <h3>Internship Progress</h3>
          <p>Overall progress of your ongoing internships:</p>
          <div className="progress-bar-container">
            <div
              className="progress-bar"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
          <p className="progress-text">{progress}% completed</p>
        </div>

        {/* Next Steps Card */}
        {/* <div className="dashboard-card next-steps-card">
          <h3>Next Steps</h3>
          <ul>
            <li>Apply for new internships</li>
            <li>Upload/Update your resume</li>
            <li>Check your application status</li>
            <li>Message companies for updates</li>
          </ul>
        </div> */}

        {/* Nested routes
        <Outlet /> */} 
      </main>
    </div>
  );
};

export default StudentDashboard;