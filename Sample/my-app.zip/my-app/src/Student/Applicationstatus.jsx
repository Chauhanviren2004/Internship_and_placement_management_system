// import React, { useEffect, useState } from "react";

// const ApplicationStatus = () => {
//   const [applications, setApplications] = useState([]);
//   const [filter, setFilter] = useState("All");
//   const [sortBy, setSortBy] = useState("date");

//   useEffect(() => {
//     const storedApps = JSON.parse(localStorage.getItem("applications")) || [];
//     setApplications(storedApps);
//   }, []);

//   const getBadge = (status) => {
//     if (status === "Pending") return "bg-warning text-dark";
//     if (status === "Shortlisted") return "bg-success text-white";
//     if (status === "Rejected") return "bg-danger text-white";
//   };

//   const filteredApps = applications
//     .filter((app) => (filter === "All" ? true : app.status === filter))
//     .sort((a, b) => {
//       if (sortBy === "date") return new Date(b.date) - new Date(a.date);
//       if (sortBy === "company") return a.company.localeCompare(b.company);
//       return 0;
//     });

//   return (
//     <div className="application-status-container">
//       <h4>My Applications</h4>

//       {/* Filters & Sorting */}
//       <div className="filter-sort-bar">
//         <div>
//           <label>Filter by Status: </label>
//           <select value={filter} onChange={(e) => setFilter(e.target.value)}>
//             <option>All</option>
//             <option>Pending</option>
//             <option>Shortlisted</option>
//             <option>Rejected</option>
//           </select>
//         </div>

//         <div>
//           <label>Sort by: </label>
//           <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
//             <option value="date">Applied Date</option>
//             <option value="company">Company</option>
//           </select>
//         </div>
//       </div>

//       {filteredApps.length === 0 ? (
//         <p className="no-apps">No applications found.</p>
//       ) : (
//         <table className="applications-table">
//           <thead>
//             <tr>
//               <th>Company</th>
//               <th>Role</th>
//               <th>Applied Date</th>
//               <th>Status</th>
//             </tr>
//           </thead>
//           <tbody>
//             {filteredApps.map((app) => (
//               <tr key={app.id}>
//                 <td>{app.company}</td>
//                 <td>{app.role}</td>
//                 <td>{app.date}</td>
//                 <td>
//                   <span className={`badge ${getBadge(app.status)}`}>
//                     {app.status}
//                   </span>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       )}
//     </div>
//   );
// };

// export default ApplicationStatus;


import React, { useState, useEffect } from "react";
import Sidebar from "./Sidebar";

function ApplicationStatus() {
  const [applications, setApplications] = useState([]);
  const [filter, setFilter] = useState("All");
  const [sortBy, setSortBy] = useState("date");

  useEffect(() => {
    const storedApps =
      JSON.parse(localStorage.getItem("applications")) || [];

    setApplications(storedApps);
  }, []);

  const getBadge = (status) => {
    if (status === "Pending") return "badge pending";
    if (status === "Shortlisted") return "badge success";
    if (status === "Rejected") return "badge danger";
    return "badge";
  };

  const filteredApps = applications
    .filter((app) => (filter === "All" ? true : app.status === filter))
    .sort((a, b) => {
      if (sortBy === "date")
        return new Date(b.date) - new Date(a.date);

      if (sortBy === "company")
        return a.company.localeCompare(b.company);

      return 0;
    });

  return (
    <>
      <Sidebar />

      <div className="app-container">
        <h2 className="title">My Applications</h2>

        {/* FILTER + SORT */}
        <div className="controls">
          <div>
            <label>Filter</label>
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            >
              <option>All</option>
              <option>Pending</option>
              <option>Shortlisted</option>
              <option>Rejected</option>
            </select>
          </div>

          <div>
            <label>Sort</label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              <option value="date">Applied Date</option>
              <option value="company">Company</option>
            </select>
          </div>
        </div>

        {/* TABLE */}
        {filteredApps.length === 0 ? (
          <p className="no-data">No applications found.</p>
        ) : (
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Company</th>
                  <th>Role</th>
                  <th>Resume</th>
                  <th>Date</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                {filteredApps.map((app) => (
                  <tr key={app.id}>
                    <td>{app.name}</td>
                    <td>{app.email}</td>
                    <td>{app.company}</td>
                    <td>{app.role}</td>
                    <td>{app.resume || "N/A"}</td>
                    <td>{app.date}</td>
                    <td>
                      <span className={getBadge(app.status)}>
                        {app.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}

export default ApplicationStatus;