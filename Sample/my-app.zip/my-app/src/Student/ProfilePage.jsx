// import React, { useState } from "react";


// function ProfilePage() {
//   const [formData, setFormData] = useState({
//     name: "",
//     email: "",
//     phone: "",
//     college: "",
//     skills: "",
//     experience: "Fresher",
//     description: ""
//   });

//   const handleChange = (e) => {
//     setFormData({
//       ...formData,
//       [e.target.name]: e.target.value
//     });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     console.log(formData);
//     alert("Profile Saved Successfully!");
//   };

//   return (
//     <div className="profile-container">
//       <h2>Student Profile</h2>

//       <form onSubmit={handleSubmit} className="profile-form">

//         <input
//           type="text"
//           name="name"
//           placeholder="Enter Name"
//           value={formData.name}
//           onChange={handleChange}
//         />

//         <input
//           type="email"
//           name="email"
//           placeholder="Enter Email"
//           value={formData.email}
//           onChange={handleChange}
//         />

//         <input
//           type="text"
//           name="phone"
//           placeholder="Enter Phone Number"
//           value={formData.phone}
//           onChange={handleChange}
//         />

//         <input
//           type="text"
//           name="college"
//           placeholder="Enter College Name"
//           value={formData.college}
//           onChange={handleChange}
//         />

//         <input
//           type="text"
//           name="skills"
//           placeholder="Enter Skills (e.g. React, Node)"
//           value={formData.skills}
//           onChange={handleChange}
//         />

//         <select
//           name="experience"
//           value={formData.experience}
//           onChange={handleChange}
//         >
//           <option value="Fresher">Fresher</option>
//           <option value="Experience">Experience</option>
//         </select>

//         <textarea
//           name="description"
//           placeholder="Enter Description"
//           value={formData.description}
//           onChange={handleChange}
//         ></textarea>

//         <button type="submit">Save Profile</button>

//       </form>
//     </div>
//   );
// }

// export default ProfilePage;


// import React, { useState } from "react";

// function ProfilePage() {
//   const [formData, setFormData] = useState({
//     name: "",
//     email: "",
//     phone: "",
//     college: "",
//     skills: "",
//     description: ""
//   });

//   const handleChange = (e) => {
//     setFormData({
//       ...formData,
//       [e.target.name]: e.target.value
//     });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();

//     // ✅ Send data to backend (example)
//     fetch("http://127.0.0.1:8000/student/create_profile", {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json"
//       },
//       body: JSON.stringify(formData)
//     })
//       .then((res) => res.json())
//       .then((data) => {
//         console.log("Profile saved:", data);
//         alert("Profile Saved Successfully!");
//       })
//       .catch((err) => {
//         console.log("Error:", err);
//       });
//   };

//   return (
//     <div className="profile-container">
//       <h2>Student Profile</h2>

//       <form onSubmit={handleSubmit} className="profile-form">

//         <input
//           type="text"
//           name="name"
//           placeholder="Enter Name"
//           value={formData.name}
//           onChange={handleChange}
//         />

//         <input
//           type="email"
//           name="email"
//           placeholder="Enter Email"
//           value={formData.email}
//           onChange={handleChange}
//         />

//         <input
//           type="text"
//           name="phone"
//           placeholder="Enter Phone Number"
//           value={formData.phone}
//           onChange={handleChange}
//         />

//         <input
//           type="text"
//           name="college"
//           placeholder="Enter College Name"
//           value={formData.college}
//           onChange={handleChange}
//         />

//         <input
//           type="text"
//           name="skills"
//           placeholder="Enter Skills (e.g. React, Node)"
//           value={formData.skills}
//           onChange={handleChange}
//         />

//         <textarea
//           name="description"
//           placeholder="Enter Description"
//           value={formData.description}
//           onChange={handleChange}
//         ></textarea>

//         <button type="submit">Save Profile</button>

//       </form>
//     </div>
//   );
// }

// export default ProfilePage;


// import React, { useState } from "react";


// function ProfilePage() {
//   const [formData, setFormData] = useState({
//     name: "",
//     email: "",
//     phone: "",
//     college: "",
//     skills: "",
//     description: ""
//   });

//   const [savedProfile, setSavedProfile] = useState(null);
//   const [isEditing, setIsEditing] = useState(false);

//   const handleChange = (e) => {
//     setFormData({
//       ...formData,
//       [e.target.name]: e.target.value
//     });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();

//     fetch("http://127.0.0.1:8000/student/create_profile", {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json"
//       },
//       body: JSON.stringify(formData)
//     })
//       .then((res) => res.json())
//       .then((data) => {
//         setSavedProfile(formData); // store locally
//         setIsEditing(false);
//         alert("Profile Saved Successfully!");
//       })
//       .catch((err) => {
//         console.log("Error:", err);
//       });
//   };

//   const handleEdit = () => {
//     setIsEditing(true);
//   };

//   const handleDelete = () => {
//     setSavedProfile(null);
//     setFormData({
//       name: "",
//       email: "",
//       phone: "",
//       college: "",
//       skills: "",
//       description: ""
//     });
//   };

//   return (
//     <div className="profile-container">
//       <h2>Student Profile</h2>

//       {/* ✅ SHOW FORM */}
//       {(isEditing || !savedProfile) && (
//         <form onSubmit={handleSubmit} className="profile-form">

//           <input type="text" name="name" placeholder="Enter Name"
//             value={formData.name} onChange={handleChange} />

//           <input type="email" name="email" placeholder="Enter Email"
//             value={formData.email} onChange={handleChange} />

//           <input type="text" name="phone" placeholder="Enter Phone Number"
//             value={formData.phone} onChange={handleChange} />

//           <input type="text" name="college" placeholder="Enter College Name"
//             value={formData.college} onChange={handleChange} />

//           <input type="text" name="skills" placeholder="Enter Skills (e.g. React, Node)"
//             value={formData.skills} onChange={handleChange} />

//           <textarea name="description" placeholder="Enter Description"
//             value={formData.description} onChange={handleChange}></textarea>

//           <button type="submit">
//             {isEditing ? "Update Profile" : "Save Profile"}
//           </button>

//         </form>
//       )}

//       {/* ✅ SHOW PROFILE CARD */}
//       {savedProfile && !isEditing && (
//         <div className="profile-card">
//           <h3>{savedProfile.name}</h3>
//           <p><strong>Email:</strong> {savedProfile.email}</p>
//           <p><strong>Phone:</strong> {savedProfile.phone}</p>
//           <p><strong>College:</strong> {savedProfile.college}</p>
//           <p><strong>Skills:</strong> {savedProfile.skills}</p>
//           <p><strong>Description:</strong> {savedProfile.description}</p>

//           <div className="profile-actions">
//             <button className="edit-btn" onClick={handleEdit}>Edit</button>
//             <button className="delete-btn" onClick={handleDelete}>Delete</button>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }

// export default ProfilePage;




import React, { useState } from "react";

function ProfilePage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    college: "",
    skills: "",
    description: ""
  });

  const [savedProfile, setSavedProfile] = useState(null);
  const [studentId, setStudentId] = useState(null); // store student ID
  const [isEditing, setIsEditing] = useState(false);

  // Handle input changes
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  // Create or Update Profile
  const handleSubmit = (e) => {
    e.preventDefault();

    if (isEditing && studentId) {
      // Update API
      fetch(`http://127.0.0.1:8000/student/updateProfile/${studentId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData)
      })
        .then((res) => res.json())
        .then((data) => {
          setSavedProfile(formData);
          setIsEditing(false);
          alert("Profile Updated Successfully!");
        })
        .catch((err) => {
          console.error("Update Error:", err);
          alert("Update Failed!");
        });
    } else {
      // Create API
      fetch("http://127.0.0.1:8000/student/create_profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData)
      })
        .then((res) => res.json())
        .then((data) => {
          setSavedProfile(formData);
          setIsEditing(false);

          // ✅ Automatically detect student ID from backend response
          // Check for different possible response keys
          const id = data.student_id || data.id || (data.data && data.data.student_id);
          setStudentId(id);

          alert("Profile Saved Successfully!");
        })
        .catch((err) => {
          console.error("Create Error:", err);
          alert("Save Failed!");
        });
    }
  };

  // Edit button
  const handleEdit = () => setIsEditing(true);

  // Delete button
  const handleDelete = () => {
    if (!studentId) {
      alert("Student ID missing! Cannot delete profile.");
      return;
    }

    fetch(`http://127.0.0.1:8000/student/deletestudentprofile/${studentId}`, {
      method: "DELETE"
    })
      .then((res) => {
        if (!res.ok) throw new Error(`Delete failed with status ${res.status}`);
        return res.text(); // safer for FastAPI DELETE
      })
      .then(() => {
        setSavedProfile(null);
        setStudentId(null);
        setFormData({
          name: "",
          email: "",
          phone: "",
          college: "",
          skills: "",
          description: ""
        });
        setIsEditing(false);
        alert("Profile Deleted Successfully!");
      })
      .catch((err) => {
        console.error("Delete Error:", err);
        alert("Delete Failed! Check console for details.");
      });
  };

  return (
    <div className="profile-container">
      <h2>Student Profile</h2>

      {/* Form */}
      {(isEditing || !savedProfile) && (
        <form onSubmit={handleSubmit} className="profile-form">
          <input
            type="text"
            name="name"
            placeholder="Enter Name"
            value={formData.name}
            onChange={handleChange}
            required
          />
          <input
            type="email"
            name="email"
            placeholder="Enter Email"
            value={formData.email}
            onChange={handleChange}
            required
          />
          <input
            type="text"
            name="phone"
            placeholder="Enter Phone Number"
            value={formData.phone}
            onChange={handleChange}
            required
          />
          <input
            type="text"
            name="college"
            placeholder="Enter College Name"
            value={formData.college}
            onChange={handleChange}
          />
          <input
            type="text"
            name="skills"
            placeholder="Enter Skills"
            value={formData.skills}
            onChange={handleChange}
          />
          <textarea
            name="description"
            placeholder="Enter Description"
            value={formData.description}
            onChange={handleChange}
          ></textarea>

          <button type="submit">
            {isEditing ? "Update Profile" : "Save Profile"}
          </button>
        </form>
      )}

      {/* Profile Card */}
      {savedProfile && !isEditing && (
        <div className="profile-card">
          <h3>{savedProfile.name}</h3>
          <p><strong>Email:</strong> {savedProfile.email}</p>
          <p><strong>Phone:</strong> {savedProfile.phone}</p>
          <p><strong>College:</strong> {savedProfile.college}</p>
          <p><strong>Skills:</strong> {savedProfile.skills}</p>
          <p><strong>Description:</strong> {savedProfile.description}</p>

          <div className="profile-actions">
            <button className="edit-btn" onClick={handleEdit}>Edit</button>
            <button className="delete-btn" onClick={handleDelete}>Delete</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default ProfilePage;