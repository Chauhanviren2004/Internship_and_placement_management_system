import React, { useState } from "react";
import Navbar from "./Navbar";

// Sample internship data
const internshipsData = [
  { id: 1, company: "Google LLC", role: "SWE Intern", location: "Remote", type: "Fresher" },
  { id: 2, company: "Microsoft", role: "Frontend Intern", location: "USA", type: "Experienced" },
  { id: 3, company: "InnoSoft", role: "React Developer", location: "India", type: "Fresher" },
  { id: 4, company: "CodeCraft", role: "UI/UX Designer", location: "Remote", type: "Experienced" },
  { id: 5, company: "TechNova", role: "Fullstack Intern", location: "Canada", type: "Fresher" },
  { id: 6, company: "InnoTech", role: "Data Science Intern", location: "Remote", type: "Fresher" },
  { id: 7, company: "Alpha Corp", role: "Marketing Intern", location: "USA", type: "Experienced" },
  { id: 8, company: "BetaSoft", role: "Finance Intern", location: "India", type: "Fresher" },
  { id: 9, company: "Creative Labs", role: "Design Intern", location: "Remote", type: "Experienced" },
  { id: 10, company: "NextGen", role: "Software Engineering Intern", location: "Canada", type: "Fresher" },
];

const InternshipPage = () => {
  const [filterType, setFilterType] = useState("All");
  const [filterLocation, setFilterLocation] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredInternships = internshipsData.filter((intern) => {
    const matchType = filterType === "All" || intern.type === filterType;
    const matchLocation = filterLocation === "All" || intern.location === filterLocation;
    const matchSearch =
      intern.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      intern.role.toLowerCase().includes(searchQuery.toLowerCase());
    return matchType && matchLocation && matchSearch;
  });

  return (
    <>
    <Navbar/>
    <div className="internship-page">
      <h1>Explore Internships</h1>

      {/* Search + Filters */}
      <div className="filters">
        <input
          type="text"
          placeholder="Search by company or role"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />

        <select value={filterType} onChange={(e) => setFilterType(e.target.value)}>
          <option value="All">All Types</option>
          <option value="Fresher">Fresher</option>
          <option value="Experienced">Experienced</option>
        </select>

        <select value={filterLocation} onChange={(e) => setFilterLocation(e.target.value)}>
          <option value="All">All Locations</option>
          <option value="Remote">Remote</option>
          <option value="USA">USA</option>
          <option value="India">India</option>
          <option value="Canada">Canada</option>
        </select>
      </div>

      {/* Internship Cards */}
      <div className="internship-list">
        {filteredInternships.length > 0 ? (
          filteredInternships.map((intern) => (
            <div key={intern.id} className="internship-card">
              <h3>{intern.company}</h3>
              <p><strong>Role:</strong> {intern.role}</p>
              <p><strong>Location:</strong> {intern.location}</p>
              <p><strong>Type:</strong> {intern.type}</p>
              <button>Apply Now</button>
            </div>
          ))
        ) : (
          <p>No internships found.</p>
        )}
      
      </div>
    </div>
    </>
  );
};

export default InternshipPage;